<?php
include('db.php');


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Duaa Mart</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <style type="text/css">
    font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        .container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .container input[type="text"], 
        .container input[type="email"], 
        .container input[type="password"], 
        .container input[type="file"], 
        .container textarea {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        .container button {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        .container button:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>
    <!-- Topbar Start -->
        <?php include('section/c_header.php'); ?>

    <!-- Navbar End -->

    <<div class="container">
    <h2>Edit Customer</h2>
    <?php
    // Check if customer ID is set
    if (isset($_GET['user_id'])) {
        $user_id = $_GET['user_id'];

        // Prepare SQL statement to fetch customer details
        $sql = "SELECT * FROM customers WHERE user_id = ?";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if customer exists
        if ($result->num_rows > 0) {
            $customer = $result->fetch_assoc();
            ?>
            <form id="editCustomerForm" method="POST" enctype="multipart/form-data" action="">
                <input type="hidden" name="user_id" value="<?php echo $customer['user_id']; ?>">

                <label for="first_name">First Name:</label>
                <input type="text" id="first_name" name="first_name" value="<?php echo $customer['first_name']; ?>" required>

                <label for="last_name">Last Name:</label>
                <input type="text" id="last_name" name="last_name" value="<?php echo $customer['last_name']; ?>" required>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo $customer['email']; ?>" required>

                <label for="address">Address:</label>
                <textarea id="address" name="address" rows="4" required><?php echo $customer['address']; ?></textarea>

                <label for="phone">Phone:</label>
                <input type="tel" id="phone" name="phone" value="<?php echo $customer['phone']; ?>" required>

                <label for="image_path">Profile Image:</label>
                <input type="file" id="image_path" name="image_path">
                <?php if ($customer['image_path']) { ?>
                    <p>Current image: <?php echo $customer['image_path']; ?></p>
                <?php } ?>

                <button type="submit" name="update" style="width:150px;">Update Customer</button>
            </form>
            <?php
        } else {
            echo "Customer not found.";
        }

      
    } else {
        echo "Customer ID is not set.";
    }

    // Check if form is submitted for update
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update"])) {
        // Retrieve form data
        $user_id = $_POST["user_id"];
        $first_name = $_POST["first_name"];
        $last_name = $_POST["last_name"];
        $email = $_POST["email"];
        $address = $_POST["address"];
        $phone = $_POST["phone"];

        // Connect to MySQL database (Change the credentials accordingly)

        // Handle image upload
        $image_path = null;
        if (isset($_FILES['image_path']) && $_FILES['image_path']['error'] == 0) {
            $target_dir = "uploads/";
            $target_file = $target_dir . basename($_FILES["image_path"]["name"]);
            if (move_uploaded_file($_FILES["image_path"]["tmp_name"], $target_file)) {
                $image_path = $target_file;
            }
        }

        // Prepare SQL statement to update data in customers table
        if ($image_path) {
            $sql = "UPDATE customers SET first_name=?, last_name=?, email=?, address=?, phone=?, image_path=? WHERE user_id=?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("ssssssi", $first_name, $last_name, $email, $address, $phone, $image_path, $user_id);
        } else {
            $sql = "UPDATE customers SET first_name=?, last_name=?, email=?, address=?, phone=? WHERE user_id=?";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("sssssi", $first_name, $last_name, $email, $address, $phone, $user_id);
        }

        if ($stmt->execute() === TRUE) {
                  echo "<script>
                alert('Profile has been Updated');
                window.location.href = 'profile.php';
              </script>";

        } else {
            echo "Error: " . $sql . "<br>" . $con->error;
        }

        // Close connection
        $stmt->close();
        $con->close();
    }
    ?>
</div>

    <!-- Footer Start -->
    <?php include('footer/footer.php'); ?>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>

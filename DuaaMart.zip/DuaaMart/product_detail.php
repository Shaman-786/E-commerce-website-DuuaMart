<?php
session_start();
include('db.php'); // Database connection

// Function to add a product to the cart
function addToCart($con, $productId, $customerId, $productName, $productPrice, $image) {
    // Check if customer is logged in
    if ($customerId === null) {
        header("Location: login.php");
        exit;
    }
}

// Initialize variables
$product = null;
$wishlist_count = 0;
$count = 0;

// Function to fetch product details
function getProductDetails($con, $productId) {
    $query = "SELECT * FROM products WHERE id = ?";
    if ($stmt = $con->prepare($query)) {
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    } else {
        return null;
    }
}

// Function to count wishlist items
function getWishlistCount($con) {
    $sql = "SELECT COUNT(*) as count FROM wishlist";
    $result = $con->query($sql);
    if ($result !== false) {
        return $result->fetch_assoc()['count'];
    } else {
        return 0;
    }
}

// Function to count cart items
function getCartCount($con) {
    $query = "SELECT COUNT(*) AS count FROM cart_items";
    $result = $con->query($query);
    if ($result !== false) {
        return $result->fetch_assoc()['count'];
    } else {
        return 0;
    }
}

// Check if the 'id' parameter is set in the URL
if (isset($_GET['id'])) {
    $productId = $_GET['id'];
    $product = getProductDetails($con, $productId);
    if (!$product) {
        echo "<p>Product not found.</p>";
        exit();
    }
} else {
    echo "<p>Product ID is missing.</p>";
    exit();
}


// Handle form submission for adding to cart or quick order
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if Buy Now was clicked
    if (isset($_POST['BuyNow'])) {
        $product_id = $_POST['product_id'];
        $product_name = $_POST['product_name'];
        $product_price = $_POST['product_price'];
       $customerId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;


        // Insert into order_products table
        $product_quantity = 1; // Assuming quantity is 1 for Buy Now
        $query = "INSERT INTO order_products (product_id, customer_id, product_name, product_price, product_quantity) 
                  VALUES (?, ?, ?, ?, ?)";

        if ($stmt = $con->prepare($query)) {
            $stmt->bind_param('iisdi', $product_id, $customerId, $product_name, $product_price, $product_quantity);
            if ($stmt->execute()) {
                // Redirect or do something after successful insertion
                header('Location: Order.php?id=' . $product_id . '&name=' . urlencode($product_name) . '&price=' . $product_price);
                exit();
            } else {
                // Handle execution error
                echo "<p>Error processing quick order.</p>";
            }
        } else {
            // Handle query preparation error
            echo "<p>Database query failed.</p>";
        }
    }
}



// Fetch counts
$wishlist_count = getWishlistCount($con);
$count = getCartCount($con);

// Close the database connection
$con->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Duaa Mart</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">
    <link href="img/favicon.ico" rel="icon">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Topbar Start -->
    <?php include('section/c_header.php'); ?>

    <!-- Breadcrumb Start -->
    <div class="container-fluid">
        <div class="row px-xl-5">
            <div class="col-12">
                <nav class="breadcrumb bg-light mb-30 bg-light">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="Product.php">Products</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo $product['productName']; ?></li>
                </nav>
            </div>
        </div>
    </div>
    <!-- Breadcrumb End -->

    <!-- Product Details Start -->
    <div class="container-fluid mb-50">
        <div class="row px-xl-5">
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body p-0">
                        <img src="dashmin/<?php echo $product['p_img']; ?>" class="img-fluid" alt="<?php echo $product['productName']; ?>">
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h4 class="mb-3"><?php echo $product['productName']; ?></h4>
                        <p class="mb-3 text-muted"><?php echo $product['productDescription']; ?></p>
                        <h5 class="mb-3">Price: $<?php echo $product['productPrice']; ?></h5>
                        <form method="post">
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            <input type="hidden" name="product_name" value="<?php echo $product['productName']; ?>">
                            <input type="hidden" name="product_price" value="<?php echo $product['productPrice']; ?>">
                            <button type="submit" name="BuyNow" class="btn btn-primary">Buy Now</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Product Details End -->

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light py-3">
        <div class="row px-xl-5">
            <div class="col-lg-6 mb-3 mb-lg-0">
                <h5 class="mb-3">Duaa Mart</h5>
                <p class="text-muted small mb-2">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nostrum tempora error reiciendis quos omnis aperiam modi, reprehenderit, iste suscipit.</p>
                <p class="text-muted small">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum, alias?</p>
            </div>
            <div class="col-lg-3 col-md-6">
                <h5 class="mb-3">Useful Links</h5>
                <div class="d-flex flex-column justify-content-start">
                    <a href="index.php" class="text-muted small mb-1">Home</a>
                    <a href="about.php" class="text-muted small mb-1">About us</a>
                    <a href="Product.php" class="text-muted small mb-1">Products</a>
                    <a href="store.php" class="text-muted small mb-1">Store</a>
                    <a href="contact.php" class="text-muted small mb-1">Contact</a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <h5 class="mb-3">Contact</h5>
                <p class="text-muted small mb-2">+92 318 3288 238</p>
                <p class="text-muted small">info@duaamart.com</p>
            </div>
        </div>
    </div>
    <!-- Footer End -->
    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

    <!-- Scripts -->
    <script src="lib/jquery/jquery.min.js"></script>
    <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html>

<?php include('db.php');
if (!isset($_SESSION['logged_in'])) {
    header('Location: login.php');
    exit;
} ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Duaa Mart</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid">
        
        <div class="row align-items-center bg-light py-3 px-xl-5 d-none d-lg-flex">
            <div class="col-lg-4">
                <a href="" class="text-decoration-none">
                    <span class="h1 text-uppercase text-primary bg-dark px-2">Duaa</span>
                    <span class="h1 text-uppercase text-dark bg-primary px-2 ml-n1">Mart</span>
                </a>
            </div>
            <div class="col-lg-4 col-6 text-left">
                <form action="">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search for products">
                        <div class="input-group-append">
                            <span class="input-group-text bg-transparent text-primary">
                                <i class="fa fa-search"></i>
                            </span>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-4 col-6 text-right">
                <p class="m-0">Customer Service</p>
                <h5 class="m-0">+012 345 6789</h5>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
   <div class="container-fluid bg-dark mb-30">
        <div class="row px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a class="btn d-flex align-items-center justify-content-between bg-primary w-100" data-toggle="collapse" href="#navbar-vertical" style="height: 65px; padding: 0 30px;">
                    <h6 class="text-dark m-0"><i class="fa fa-bars mr-2"></i>Categories</h6>
                    <i class="fa fa-angle-down text-dark"></i>
                </a>
                <nav class="collapse position-absolute navbar navbar-vertical navbar-light align-items-start p-0 bg-light" id="navbar-vertical" style="width: calc(100% - 30px); z-index: 999;">
                    <div class="navbar-nav w-100">
                        <a href="Mobile.php" class="nav-item nav-link">Mobile</a>
                        <a href="Computer.php" class="nav-item nav-link">Computer</a>
                        <a href="Jewelry.php" class="nav-item nav-link">Jewelry</a>
                         <a href="women.php" class="nav-item nav-link">Men</a>
                         <a href="men.php" class="nav-item nav-link">Women</a>
                         <a href="kids.php" class="nav-item nav-link">Kids</a>
                </nav>
            </div>
            <div class="col-lg-9">
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-0">
                    <a href="" class="text-decoration-none d-block d-lg-none">
                        <span class="h1 text-uppercase text-dark bg-light px-2">Duaa</span>
                        <span class="h1 text-uppercase text-light bg-primary px-2 ml-n1">Mart</span>
                    </a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto py-0">
                            <a href="index.php" class="nav-item nav-link">Home</a>
                            <a href="about.php" class="nav-item nav-link">About us</a>
                          
                            <a href="Product.php" class="nav-item nav-link">Products</a>
                            <a href="store.php" class="nav-item nav-link">Store</a>
                            <a href="contact.php" class="nav-item nav-link">Contact</a>

                        </div> </div>
                        <div class="navbar-nav ml-auto py-0 d-none d-lg-block">
                            <a href="wishlist.php" class="btn px-0">
                                <i class="fas fa-heart text-primary"></i>
                                <span class="badge text-secondary border border-secondary rounded-circle" style="padding-bottom: 2px;">0</span>
                            </a>


                            <?php
                $count = 0;
                if (isset($_SESSION['cart'])) {
                    $count = count($_SESSION['cart']);
                }
                ?>
                            <a href="cart.php" class="btn px-0 ml-3">
    <i class="fas fa-shopping-cart text-primary"></i>
    <?php
    // Fetch count of items in cart from database
    $query = "SELECT COUNT(*) AS count FROM cart_items";
    $result = $con->query($query);
    $row = $result->fetch_assoc();
    $count = isset($row['count']) ? $row['count'] : 0;
    ?>
    <span class="badge text-secondary border border-secondary rounded-circle" style="padding-bottom: 2px;"><?php echo $count; ?></span>
</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- Navbar End -->

    <!-- Breadcrumb Start -->
    <div class="container-fluid">
        <div class="row px-xl-5">
            <div class="col-12">
                <nav class="breadcrumb bg-light mb-30">
                    <a class="breadcrumb-item text-dark" href="index.php">Home</a>
                    <a class="breadcrumb-item text-dark" href="Product.php">Product</a>
                    <span class="breadcrumb-item active">Shopping Cart</span>
                </nav>
            </div>
        </div>
    </div>
    <!-- Breadcrumb End -->
<?php
// Fetch cart items from the database
$query = "SELECT * FROM cart_items";
$result = mysqli_query($con, $query);

$subtotal = 0;
?>

<div class="container-fluid">
    <div class="row px-xl-5">
        <div class="col-lg-8 table-responsive mb-5">
            <table class="table table-light table-borderless table-hover text-center mb-0">
                <thead class="thead-dark">
                    <tr>
                        <th>Products</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Remove</th>
                    </tr>
                </thead>
                <tbody class="align-middle">
                    <?php
                    while ($row = mysqli_fetch_array($result)) {
                        $id = $row['p_id'];
                        $p_name = $row['p_name'];
                        $price = $row['price'];
                        $image = $row['image'];
                        $quantity = 1; // Default quantity

                        // Calculate total price
                        $total = $price * $quantity;
                        $subtotal += $total; // Add to subtotal

                        echo "
                            <tr>
                                <td class='align-middle'><img src='$image' alt='' style='width: 50px;'> $p_name</td>
                                <td class='align-middle' id='price_$id'>$$price</td>
                                <td class='align-middle'>
                                    <div class='input-group quantity mx-auto' style='width: 100px;'>
                                        <input type='number' id='quantity_$id' class='form-control form-control-sm bg-secondary border-0 text-center' value='$quantity' min='1'>
                                    </div>
                                </td>
                                <td class='align-middle' id='total_$id'>$$total</td>
                                <td class='align-middle'><a href='deletecart.php?id=$id' class='btn btn-sm btn-danger'><i class='fa fa-times'></i></a></td>
                            </tr>
                        ";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <div class="col-lg-4">
            <form class="mb-30" action="">
                <div class="input-group">
                    <input type="text" class="form-control border-0 p-4" placeholder="Coupon Code">
                    <div class="input-group-append">
                        <button class="btn btn-primary">Apply Coupon</button>
                    </div>
                </div>
            </form>
            <?php


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Fetch cart items from the database
    $query = "SELECT * FROM cart_items";
    $result = mysqli_query($con, $query);

    // Check if there are items in the cart
    if (mysqli_num_rows($result) > 0) {
        // Loop through each cart item and insert it into the checkout_items table
        while ($row = mysqli_fetch_assoc($result)) {
            $p_id = $row['p_id'];
            $p_name = $row['p_name'];
            $price = $row['price'];
            $quantity = $row['quantity'];
            $image = $row['image'];

            // Insert into checkout_items table
            $insertQuery = "INSERT INTO checkout_items (p_id, p_name, price, quantity, image) VALUES ('$p_id', '$p_name', '$price', '$quantity', '$image')";
            mysqli_query($con, $insertQuery);
        }

        // Clear the cart
        $clearCartQuery = "DELETE FROM cart_items";
        mysqli_query($con, $clearCartQuery);

        // Redirect to a confirmation page or the next step in the checkout process
        header('Location: checkout.php');
        exit();
    } else {
        echo "No items in the cart.";
    }
} else {
    echo "Invalid request method.";
}
?>
            <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Cart Summary</span></h5>
            <div class="bg-light p-30 mb-5">
                <div class="border-bottom pb-2">
                    <div class="d-flex justify-content-between mb-3">
                        <h6>Subtotal</h6>
                        <h6 id="subtotal">$<?php echo number_format($subtotal, 2); ?></h6>
                    </div>
                    <div class="d-flex justify-content-between">
                        <h6 class="font-weight-medium">Shipping</h6>
                        <h6 class="font-weight-medium">$10.00</h6>
                    </div>
                </div>
                <div class="pt-2">
                    <div class="d-flex justify-content-between mt-2">
                        <h5>Total</h5>
                        <h5 id="total">$<?php echo number_format($subtotal + 10, 2); ?></h5>
                    </div>
                    <form action="checkout.php" method="POST">
    <button type="submit" class="btn btn-block btn-primary font-weight-bold my-3 py-3">Proceed To Checkout</button>
</form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.querySelectorAll("input[type='number']").forEach(input => {
    input.addEventListener('change', function() {
        let id = this.id.split('_')[1];
        let quantity = parseInt(this.value);
        let price = parseFloat(document.getElementById('price_' + id).textContent.substring(1));
        let totalElement = document.getElementById('total_' + id);
        let newTotal = price * quantity;
        
        totalElement.textContent = '$' + newTotal.toFixed(2);
        
        updateSubtotal();
    });
});

function updateSubtotal() {
    let subtotal = 0;
    document.querySelectorAll("td[id^='total_']").forEach(total => {
        subtotal += parseFloat(total.textContent.substring(1));
    });
    
    document.getElementById('subtotal').textContent = '$' + subtotal.toFixed(2);
    document.getElementById('total').textContent = '$' + (subtotal + 10).toFixed(2);
}
</script>
    <div class="container-fluid bg-dark text-secondary mt-5 pt-5">
        <div class="row px-xl-5 pt-5">
            <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5">
                <h5 class="text-secondary text-uppercase mb-4">Get In Touch</h5>
                <p class="mb-4">Get in touch with Duaa Mart for personalized customer support</p>
                <p class="mb-2"><i class="fa fa-map-marker-alt text-primary mr-3"></i>B, Ghotki, Sindh 65110</p>
                <p class="mb-2"><i class="fa fa-envelope text-primary mr-3"></i>info@example.com</p>
                <p class="mb-0"><i class="fa fa-phone-alt text-primary mr-3"></i>+92 3183288238</p>
            </div>
            <div class="col-lg-8 col-md-12">
                <div class="row">
                    <div class="col-md-4 mb-5">
                        <h5 class="text-secondary text-uppercase mb-4">Quick Shop</h5>
                        <div class="d-flex flex-column justify-content-start">
                            <a class="text-secondary mb-2" href="index.php"><i class="fa fa-angle-right mr-2"></i>Home</a>
                            <a class="text-secondary mb-2" href="store.php"><i class="fa fa-angle-right mr-2"></i>Our Store</a>
                            <a class="text-secondary mb-2" href="about.php"><i class="fa fa-angle-right mr-2"></i>About us</a>
                            
                            <a class="text-secondary mb-2" href="product.php"><i class="fa fa-angle-right mr-2"></i>Products</a>
                            <a class="text-secondary" href="Contact.php"><i class="fa fa-angle-right mr-2"></i>Contact Us</a>
                        </div>
                    </div>
                    <div class="col-md-4 mb-5">
                        <h5 class="text-secondary text-uppercase mb-4">Quick links </h5>
                        <div class="d-flex flex-column justify-content-start">
                            <a class="text-secondary mb-2" href="computer.php"><i class="fa fa-angle-right mr-2"></i>Computer</a>
                            <a class="text-secondary mb-2" href="Mobile.php"><i class="fa fa-angle-right mr-2"></i>Mobile</a>
                            <a class="text-secondary mb-2" href="jewelry.php"><i class="fa fa-angle-right mr-2"></i>Jewelry</a>
                            
                            <a class="text-secondary mb-2" href="men.php"><i class="fa fa-angle-right mr-2"></i>Men</a>
                            <a class="text-secondary" href="Women.php"><i class="fa fa-angle-right mr-2"></i>Women</a>
                            <a class="text-secondary" href="kids.php"><i class="fa fa-angle-right mr-2"></i>Kids</a>
                        </div></div>
                    <div class="col-md-4 mb-5">
                        <h5 class="text-secondary text-uppercase mb-4">Newsletter</h5>
                        <p>Duaa Mart's newsletter: updates, deals, promotions.</p>
                        <form action="">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Your Email Address">
                                <div class="input-group-append">
                                    <button class="btn btn-primary">Sign Up</button>
                                </div>
                            </div>
                        </form>
                        <h6 class="text-secondary text-uppercase mt-4 mb-3">Follow Us</h6>
                        <div class="d-flex">
                            <a class="btn btn-primary btn-square mr-2" href="https://twitter.com/icreativezt?lang=en"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-primary btn-square mr-2" href="https://www.facebook.com/icreativez/"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-primary btn-square mr-2" href="https://www.linkedin.com/company/icreativez/"><i class="fab fa-linkedin-in"></i></a>
                            <a class="btn btn-primary btn-square" href="https://www.instagram.com/icreativez/"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row border-top mx-xl-5 py-4" style="border-color: rgba(256, 256, 256, .1) !important;">
            <div class="col-md-6 px-xl-0">
                <p class="mb-md-0 text-center text-md-left text-secondary">
                    &copy; <a class="text-primary" href="">Duaa</a>. All Rights Reserved. Designed
                    by
                    <a class="text-primary" href="https://shamanportfolio.000webhostapp.com/">Icreativez's team</a>
                </p>
            </div>
            <div class="col-md-6 px-xl-0 text-center text-md-right">
                <img class="img-fluid" src="img/payments.png" alt="">
            </div>
        </div>
    </div>
    <!-- Footer End -->


<!-- Back to Top -->
<a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>

<!-- Contact Javascript File -->
<script src="mail/jqBootstrapValidation.min.js"></script>
<script src="mail/contact.js"></script>

<!-- Template Javascript -->
<script src="js/main.js"></script>
</body>
</html>

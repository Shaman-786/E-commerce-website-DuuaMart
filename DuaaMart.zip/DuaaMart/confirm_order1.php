<?php
include('db.php'); // Include your database connection file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and add checks to ensure these keys exist
    $first_name = $_POST['first_name'] ?? null;
    $email = $_POST['email'] ?? null;
    $mobile = $_POST['mobile'] ?? null;
    $state = $_POST['state'] ?? null;
    $city = $_POST['city'] ?? null;
    $address = $_POST['address'] ?? null;
    $payment = $_POST['payment'] ?? null;
    $subtotal = $_POST['subtotal'] ?? null;
    $total = $_POST['total'] ?? null;
    $product_ids = $_POST['product_ids'] ?? [];
    $product_names = $_POST['product_names'] ?? [];
    $product_prices = $_POST['product_prices'] ?? [];
    $product_quantities = $_POST['product_quantities'] ?? [];

    // Insert order into confirm_order table
    $query = "INSERT INTO confirm_order (first_name, email, mobile, state, city, address, payment, subtotal, total) 
              VALUES ('$first_name', '$email', '$mobile', '$state', '$city', '$address', '$payment', '$subtotal', '$total')";
    mysqli_query($con, $query);

    // Get the last inserted order id
    $order_id = mysqli_insert_id($con);

    // Insert each product into the order_products table
    foreach ($product_ids as $index => $product_id) {
        $product_name = $product_names[$index];
        $product_price = $product_prices[$index];
        $product_quantity = $product_quantities[$index];

        $query = "INSERT INTO order_products (order_id, product_id, product_name, product_price, product_quantity) 
                  VALUES ('$order_id', '$product_id', '$product_name', '$product_price', '$product_quantity')";
        mysqli_query($con, $query);
    }

    // Delete all records from quick_order table
    $delete_query = "DELETE FROM quick_order";
    mysqli_query($con, $delete_query);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>DUAA Mart</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">

    <style>
        .card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Topbar Start -->
    <?php include('header/header.php'); ?>
    <!-- Navbar End -->

    <!-- Breadcrumb Start -->
    <div class="container-fluid">
        <div class="row px-xl-5">
            <div class="col-12">
                <nav class="breadcrumb bg-light mb-30">
                    <a class="breadcrumb-item text-dark" href="#">Home</a>
                    <a class="breadcrumb-item text-dark" href="#">Shop</a>
                    <span class="breadcrumb-item active">Quick Order Checkout</span>
                </nav>
            </div>
        </div>
    </div>
    <!-- Breadcrumb End -->

    <div class="container">
        <?php if ($_SERVER["REQUEST_METHOD"] == "POST") { ?>
            <h2 class="text-center my-4">Order Confirmation</h2>
            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Customer Details</h5>
                            <p class="card-text"><strong>Name:</strong> <?php echo $first_name; ?></p>
                            <p class="card-text"><strong>Email:</strong> <?php echo $email; ?></p>
                            <p class="card-text"><strong>Mobile:</strong> <?php echo $mobile; ?></p>
                            <p class="card-text"><strong>State:</strong> <?php echo $state; ?></p>
                            <p class="card-text"><strong>City:</strong> <?php echo $city; ?></p>
                            <p class="card-text"><strong>Address:</strong> <?php echo $address; ?></p>
                            <p class="card-text"><strong>Payment Method:</strong> <?php echo $payment; ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Order Details</h5>
                            <p class="card-text"><strong>Subtotal: $</strong> <?php echo $subtotal; ?></p>
                            <p class="card-text"><strong>Total: $</strong> <?php echo $total; ?></p>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Products</h5>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Product ID</th>
                                        <th>Product Name</th>
                                        <th>Product Price</th>
                                        <th>Product Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($product_ids as $index => $product_id) { ?>
                                        <tr>
                                            <td><?php echo $product_id; ?></td>
                                            <td><?php echo $product_names[$index]; ?></td>
                                            <td><?php echo $product_prices[$index]; ?></td>
                                            <td><?php echo $product_quantities[$index]; ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center mt-4">
                <button class="btn btn-primary" onclick="confirmOrder()">Confirm Order</button>
            </div>
        <?php } else {
            echo "<p class='text-center'>Invalid request.</p>";
        } ?>
    </div>

    <script>
    function confirmOrder() {
        // Redirect to Shop.php after confirmation
        
        window.location.href = 'thank_you.php';
    }
    </script>

</body>
</html>

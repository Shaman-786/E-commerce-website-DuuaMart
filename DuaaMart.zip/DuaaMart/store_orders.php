<?php 
// store_orders.php

// Include database connection
include('db.php');

// Fetch data from quick_order table
$query = "SELECT Q_id, id, Q_name, Q_price FROM quick_order";
$result = $con->query($query);

if ($result) {
    // Fetch all rows and store in $orders array
    $orders = [];
    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }

    // Save $orders array to a file (orders.json)
    $file_name = 'orders.json';
    $file_path = __DIR__ . "/$file_name"; // Path to the file

    // Convert orders array to JSON and save to file
    $json_data = json_encode($orders, JSON_PRETTY_PRINT);
    if (file_put_contents($file_path, $json_data)) {
        echo "Orders stored in $file_name.";
    } else {
        echo "Error storing orders in $file_name.";
    }
} else {
    // Display error message if query fails
    echo "Error: " . $con->error;
}

// Close the database connection
$con->close(); ?>
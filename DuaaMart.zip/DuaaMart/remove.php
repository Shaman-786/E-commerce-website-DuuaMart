<?php
include('db.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // SQL query to delete the item from the wishlist
    $sql = "DELETE FROM wishlist WHERE id = $id";

    if ($con->query($sql) === TRUE) {
        echo "<script>alert('Product with ID $id has been removed from your wishlist.'); window.location.href = 'wishlist.php';</script>";
    } else {
        echo "<script>alert('Error removing product: " . $con->error . "'); window.location.href = 'wishlist.php';</script>";
    }
} else {
    header('Location: wishlist.php');
    exit();
}

$con->close();
?>

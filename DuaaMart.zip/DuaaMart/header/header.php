   <!-- Topbar Start -->
    <div class="container-fluid">
        
        <div class="row align-items-center bg-light py-3 px-xl-5 d-none d-lg-flex">
            <div class="col-lg-4">
                <a href="" class="text-decoration-none">
                    <span class="h1 text-uppercase text-primary bg-dark px-2">Duaa</span>
                    <span class="h1 text-uppercase text-dark bg-primary px-2 ml-n1">Mart</span>
                </a>
            </div>
            <div class="col-lg-4 col-6 text-left">
                         <form action="searchbar.php">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search for products" name="search_query">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit" name="submit_search">
                                <i class="fa fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
           <div class="col-lg-4 col-6 text-right">
                <p class="m-0"></p>
                <h5 class="m-0 dropdown">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Account
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                        <a class="dropdown-item" href="Register.php">Register</a>
                        <a class="dropdown-item" href="login.php">Login</a>
                        
                        
                    </div>
                </h5>
            </div>
        </div>
    </div>
    <!-- Topbar End -->

    <!-- Navbar Start -->
    <div class="container-fluid bg-dark mb-30">
        <div class="row px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a class="btn d-flex align-items-center justify-content-between bg-primary w-100" data-toggle="collapse" href="#navbar-vertical" style="height: 65px; padding: 0 30px;">
                    <h6 class="text-dark m-0"><i class="fa fa-bars mr-2"></i>Categories</h6>
                    <i class="fa fa-angle-down text-dark"></i>
                </a>
                <nav class="collapse position-absolute navbar navbar-vertical navbar-light align-items-start p-0 bg-light" id="navbar-vertical" style="width: calc(100% - 30px); z-index: 999;">
                    <div class="navbar-nav w-100">
                        <a href="Mobile.php" class="nav-item nav-link">Mobile</a>
                        <a href="Computer.php" class="nav-item nav-link">Computer</a>
                        <a href="Jewelry.php" class="nav-item nav-link">Jewelry</a>
                         <a href="men.php" class="nav-item nav-link">Men</a>
                         <a href="Women.php" class="nav-item nav-link">Women</a>
                         <a href="kids.php" class="nav-item nav-link">Kids</a>
                </nav>
            </div>
            <div class="col-lg-9">
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-0">
                    <a href="" class="text-decoration-none d-block d-lg-none">
                        <span class="h1 text-uppercase text-dark bg-light px-2">Duaa</span>
                        <span class="h1 text-uppercase text-light bg-primary px-2 ml-n1">Mart</span>
                    </a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto py-0">
                            <a href="index.php" class="nav-item nav-link">Home</a>
                            <a href="about.php" class="nav-item nav-link">About us</a>
                          
                            <a href="Product.php" class="nav-item nav-link">Products</a>
                            <a href="store.php" class="nav-item nav-link">Store</a>
                            <a href="contact.php" class="nav-item nav-link">Contact</a>

                        </div> </div>
                         
                        <div class="navbar-nav ml-auto py-0 d-none d-lg-block">
                            <a href="wishlist.php" class="btn px-0">
                                <i class="fas fa-heart text-primary"></i>
                                <span class="badge text-secondary border border-secondary rounded-circle" style="padding-bottom: 2px;">0</span>
                            </a>
                            <a href="cart.php" class="btn px-0 ml-3">
                                <i class="fas fa-shopping-cart text-primary"></i>
                                <span class="badge text-secondary border border-secondary rounded-circle" style="padding-bottom: 2px;">0</span>
                            </a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- Navbar End -->


-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2024 at 02:06 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `myshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cart_items`
--

CREATE TABLE `cart_items` (
  `p_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `p_name` varchar(20) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart_items`
--

INSERT INTO `cart_items` (`p_id`, `customer_id`, `p_name`, `price`, `image`, `quantity`) VALUES
(1, 8, 'Bag', 120.00, 'uploads/download (13).jpeg', 1),
(3, 14, 'Neck less', 300.00, 'uploads/download (2).jpeg', 1),
(4, 14, 'kids Dress', 123.00, 'uploads', 1),
(5, 8, 'Smart phone', 123.00, 'uploads/images (5).jpeg', 1),
(6, 8, 'Dress', 200.00, 'uploads/images (9).jpeg', 1),
(7, 16, 'Dell Laptop', 430.00, 'uploads', 1),
(8, 20, 'Keypad ', 12.00, 'uploads', 1),
(9, 16, 'Jumka', 340.00, 'uploads', 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `CategoryId` int(10) NOT NULL,
  `CategoryName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`CategoryId`, `CategoryName`) VALUES
(1, 'Computer'),
(2, 'Mobile'),
(3, 'Jewelry '),
(4, 'Men'),
(5, 'Women'),
(6, 'Kids');

-- --------------------------------------------------------

--
-- Table structure for table `checkout`
--

CREATE TABLE `checkout` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `mobile_no` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `zip_code` varchar(10) DEFAULT NULL,
  `create_account` enum('Yes','No') DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `checkout_items`
--

CREATE TABLE `checkout_items` (
  `id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `p_name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `confirm_order`
--

CREATE TABLE `confirm_order` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `payment` varchar(50) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `confirm_order`
--

INSERT INTO `confirm_order` (`id`, `customer_id`, `first_name`, `email`, `mobile`, `state`, `city`, `address`, `payment`, `subtotal`, `total`, `created_at`) VALUES
(1, 0, 'shaman', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', 'Cash On Delivery', 0.00, 10.00, '2024-06-14 02:39:00'),
(2, 0, 'shaman', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '', 0.00, 10.00, '2024-06-14 03:27:13'),
(3, 0, 'shaman', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', 'Cash On Delivery', 0.00, 10.00, '2024-06-14 10:12:23'),
(6, 0, 'SHAMAN ALI ', 'abcll@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', 'Cash On Delivery', 35.00, 45.00, '2024-06-14 10:53:53'),
(7, 0, 'SHAMAN ALI ', 'kaaliya@gmail.com', '+923183288238', 'punjab', 'Ghotki', 'Mathelo Moomal Ji Mari Ghotki', 'Cash On Delivery', 12.00, 22.00, '2024-06-14 11:07:34'),
(10, 0, 'Kaaliya', 'kaaliya@gmail.com', '+923082731788', 'punjaba', 'Ghotki', 'sau tandojam hyderabad sindh', 'Cash On Delivery', 123.00, 133.00, '2024-06-27 05:31:12'),
(11, 0, 'SHAMAN ALI ', 'abc@gmail.com', '+923082731788', 'punjab', 'Ghotki', 'sau tandojam hyderabad sindh', 'Cash On Delivery', 120.00, 130.00, '2024-06-27 05:50:13'),
(12, 0, 'ALi', 'abdulfatahmahar9@gmail.com', '+923082731788', 'punjaba', 'Ghotki', 'sau tandojam hyderabad sindh', 'Cash On Delivery', 240.00, 250.00, '2024-06-27 06:21:16'),
(13, 0, 'SHAMAN ALI ', 'kaaliya@gmail.com', '+923183288238', 'sindh', 'Ghotki', 'Mathelo Moomal Ji Mari Ghotki', 'Cash On Delivery', 300.00, 310.00, '2024-06-30 12:52:28'),
(14, 0, 'SHAMAN ALI ', 'abc@gmail.com', '+923183288238', 'punjab', 'Ghotki', 'Mathelo Moomal Ji Mari Ghotki', 'Direct Check', 600.00, 610.00, '2024-07-01 05:06:46'),
(15, 0, 'abc', 'kaaliya@gmail.com', '+923183288238', 'sindh', 'Ghotki', 'Mathelo Moomal Ji Mari Ghotki', 'Cash On Delivery', 200.00, 210.00, '2024-07-01 05:08:57'),
(16, 8, 'SHAMAN ALI ', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', 'Cash On Delivery', 0.00, 10.00, '2024-07-08 09:41:03'),
(17, 8, 'SHAMAN ALI ', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', 'Cash On Delivery', 0.00, 10.00, '2024-07-08 09:43:59'),
(18, 8, 'SHAMAN ALI ', 'shamanalimahar462@gmail.com', '+923082731788', 'punjab', 'Ghotki', 'sau tandojam hyderabad sindh', 'Direct Check', 0.00, 10.00, '2024-07-08 09:56:13'),
(19, 8, 'SHAMAN ALI ', 'shaman2@gmail.com', '+923082731788', 'punjab', 'Ghotki', 'sau tandojam hyderabad sindh', 'Cash On Delivery', 935.00, 945.00, '2024-07-08 10:07:57'),
(20, 8, 'shaman', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', 'Direct Check', 120.00, 130.00, '2024-07-08 10:19:42'),
(21, 8, 'shaman', 'abc@gmail.com', '+923082731788', 'punjab', 'Ghotki', 'sau tandojam hyderabad sindh', 'Cash On Delivery', 120.00, 130.00, '2024-07-08 10:43:23'),
(22, 16, 'SHAMAN ALI ', 'shamanalimahar462@gmail.com', '+923183288238', 'sindh', 'Ghotki', 'Mathelo Moomal Ji Mari Ghotki', 'Cash On Delivery', 300.00, 310.00, '2024-07-08 12:02:31'),
(23, 16, 'SHAMAN ALI ', 'shamanalimahar462@gmail.com', '+923183288238', 'sindh', 'Ghotki', 'Mathelo Moomal Ji Mari Ghotki', 'Cash On Delivery', 300.00, 310.00, '2024-07-08 12:11:33'),
(24, 16, 'abc', 'abdulfatahmahar9@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', 'Direct Check', 300.00, 310.00, '2024-07-10 05:02:01'),
(25, 19, 'G.hussan', 'abc1@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', 'Cash On Delivery', 200.00, 210.00, '2024-07-10 05:40:12'),
(26, 19, 'shaman', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', 'Cash On Delivery', 200.00, 210.00, '2024-07-10 05:56:40'),
(27, 8, 'shaman', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', 'Cash On Delivery', 120.00, 130.00, '2024-07-10 09:37:33'),
(28, 8, 'shaman', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', 'Cash On Delivery', 120.00, 130.00, '2024-07-10 09:38:37'),
(29, 8, 'abc', 'abc@gmail.com', '+923183288238', 'punjab', 'Ghotki', 'Mathelo Moomal Ji Mari Ghotki', 'Cash On Delivery', 200.00, 210.00, '2024-07-10 09:39:47');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `subject`, `message`, `created_at`) VALUES
(3, 'Shaman ali', 'kaaliya@gmail.com', 'can you help me ', 'jslfjlkjdf', '0000-00-00 00:00:00'),
(4, 'Shaman ali', 'kaaliya@gmail.com', 'can you help me ', 'jslfjlkjdf', '0000-00-00 00:00:00'),
(5, 'Shaman ali', 'kaaliya@gmail.com', 'can you help me ', 'jslfjlkjdf', '2024-07-01 10:08:06'),
(6, 'ABC', 'abc@gmail.com', 'can you help me ', 'sasa', '2024-07-01 10:08:19'),
(7, 'Amar', 'abc@gmail.com', 'dfjdhfjdhfd', 'asas', '2024-07-01 10:08:54'),
(8, 'shaman ali', 'abc@gmail.com', 'can you help me ', 'sddds', '2024-07-10 10:27:39'),
(9, 'Areeba', 'areaba@gmail.com', 'can you help me ', 'asasas', '2024-07-10 11:57:12');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(15) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`user_id`, `first_name`, `last_name`, `email`, `password`, `address`, `phone`, `image_path`, `registration_date`) VALUES
(8, 'shaman', 'ali', 'abc@gmail.com', '111', 'sau tandojam hyderabad sindh', '03082731788', 'uploads/images (21).jpeg', '2024-06-25 17:12:43'),
(14, 'Ramesh', 'Kumar', 'itc@gmail.com', '111', 'Mathelo Moomal Ji Mari Ghotki', '03183288238', 'uploads/2.png', '2024-07-02 09:59:31'),
(15, 'abac', 'abv', 'avc@gmail.com', '12345', 'sau tandojam hyderabad sindh', '03082731780', 'uploads/download (1).jpeg', '2024-07-02 11:14:08'),
(16, 'shaman', 'ali', 'shamanalimahar462@gmail.com', '123', 'sau tandojam hyderabad sindh', '03082731711', 'uploads/download.jpg', '2024-07-02 11:39:06'),
(17, 'abc', 'cde', 'abc11@gmail.com', '111', 'Mathelo Moomal Ji Mari Ghotki', '03183288238', 'uploads/WhatsApp Image 2024-06-09 at 10.22.51_b81598bd.jpg', '2024-07-05 06:56:09'),
(18, 'abca', 'as', 'shaman2@gmail.com', '111', 'Mathelo Moomal Ji Mari Ghotki', '03183288238', 'uploads/White Gray Photo Work Quotes Desktop Wallpaper.png', '2024-07-05 09:44:02'),
(19, 'G.hussan', 'ali', 'abc1@gmail.com', '111', 'sau tandojam hyderabad sindh', '03082731788', 'uploads/download (23).jpeg', '2024-07-10 05:39:13'),
(20, 'Areeba', 'Mughal', 'areaba@gmail.com', '123', 'sau tandojam hyderabad sindh', '03082731780', 'uploads/WhatsApp Image 2024-06-08 at 12.47.16_57ce5bc5.jpg', '2024-07-10 11:54:41');

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` decimal(10,2) NOT NULL,
  `product_quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_products`
--

INSERT INTO `order_products` (`id`, `order_id`, `product_id`, `customer_id`, `product_name`, `product_price`, `product_quantity`) VALUES
(8, 10, 19, 0, 'Dress', 123.00, 1),
(9, 11, 20, 0, 'Bag', 120.00, 1),
(15, 15, 26, 0, 'Dress', 200.00, 1),
(16, 0, 4, 8, 'kids Dress', 123.00, 1),
(17, 0, 4, 8, 'kids Dress', 123.00, 1),
(18, 0, 4, 8, 'kids Dress', 123.00, 1),
(19, 0, 4, 8, 'kids Dress', 123.00, 1),
(20, 0, 1, 8, 'Bag', 120.00, 1),
(21, 0, 3, 16, 'Neck less', 300.00, 1),
(22, 0, 3, 16, 'Neck less', 300.00, 1),
(23, 0, 6, 19, 'Dress', 200.00, 1),
(24, 0, 1, 8, 'Bag', 120.00, 1),
(25, 0, 1, 8, 'Bag', 120.00, 1),
(26, 0, 6, 8, 'Dress', 200.00, 1),
(27, 0, 3, 8, 'Neck less', 300.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `CategoryId` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `productName` varchar(255) NOT NULL,
  `productDescription` text NOT NULL,
  `productSKU` varchar(100) NOT NULL,
  `productPrice` decimal(10,2) NOT NULL,
  `productStock` int(11) NOT NULL,
  `productBrand` varchar(100) NOT NULL,
  `productCategory` int(11) NOT NULL,
  `productTags` varchar(255) NOT NULL,
  `productReleaseDate` date NOT NULL,
  `productOnSale` tinyint(1) NOT NULL,
  `p_img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `CategoryId`, `customer_id`, `productName`, `productDescription`, `productSKU`, `productPrice`, `productStock`, `productBrand`, `productCategory`, `productTags`, `productReleaseDate`, `productOnSale`, `p_img`) VALUES
(1, 5, 0, 'Bag', 'Ladies Bag', '2', 120.00, 12, '0', 1, 'Computer', '2024-06-26', 1, 'uploads/download (13).jpeg'),
(3, 3, 0, 'Neck less', 'To optimize your web application for mobile devices, it\'s essential to focus on several key aspects of design and functionality to ensure a seamless user experience. Here\'s a detailed approach to enhance your application for mobile:', '12', 300.00, 3, '0', 5, 'Computer', '2024-07-03', 1, 'uploads/download (2).jpeg'),
(4, 1, 0, 'kids Dress', 'Ensure your server environment supports PHP and MySQL, and adjust the HTML and CSS classes as per your styling preferences. This code assumes you have Bootstrap CSS and JavaScript included for styling and functionality', 'asas', 123.00, 1, '0', 1, 'Dress', '2024-06-18', 1, 'uploads/images (15).jpeg'),
(5, 2, 0, 'Smart phone', 'Smartphones have revolutionized communication and daily life with their advanced computing capabilities and seamless connectivity.', '2dfd', 123.00, 2, '0', 0, 'Computer', '2024-06-12', 1, 'uploads/images (5).jpeg'),
(6, 5, 0, 'Dress', 'Discover elegance and style with our exquisite collection of women\'s dresses, designed to celebrate every occasion with grace and sophistication.', 'sasasa', 200.00, 2, '0', 0, 'Dress', '2024-06-25', 1, 'uploads/images (9).jpeg'),
(7, 1, 0, 'Dell Laptop', 'The Dell laptop featuring a 4th generation Intel Core i5 processor, priced at RS 43,000, comes with 8GB of RAM, offering a balance of performance and value.', 'Dell Laptop', 430.00, 12, '0', 0, 'Dell Laptop Core i5 ', '2024-07-20', 1, 'uploads/download (9).jpeg'),
(8, 2, 0, 'Keypad ', 'The keypad mobile offers a classic design with tactile buttons, providing reliable communication and simplicity for those who prefer traditional mobile phone features.', 'KeyPad', 12.00, 13, '0', 0, 'keypad ', '2024-07-11', 1, 'uploads/download (11).jpeg'),
(9, 1, 0, 'Jumka', 'Ladies jumka earrings are elegant and traditional accessories that add a touch of cultural charm and sophistication to any outfit, perfect for various occasions.', 'Jumka', 340.00, 2, '0', 0, 'Jumka ', '2024-07-05', 1, 'uploads/download (6).jpeg'),
(10, 5, 0, 'Ladies Bag', 'The ladies\' handbag combines elegance and functionality, perfect for carrying essentials with style and convenience wherever you go.', 'Daraz', 60.00, 12, '0', 0, 'Ladies Bag', '2024-07-04', 1, 'uploads/download (14).jpeg'),
(11, 6, 0, 'kids School Bag', 'The kids\' school bag blends durability and comfort, designed to safely carry books and supplies while ensuring ease of use for young students.', 'Kids', 12.00, 34, '0', 0, 'School Bag', '2024-07-18', 1, 'uploads/images (14).jpeg'),
(12, 4, 0, 'Laptop Bag', 'The laptop bag combines durability and organization, designed to protect and carry your laptop and accessories comfortably and securely.', 'Laptop Bag', 123.00, 34, '0', 0, 'laptop Bag', '2024-07-09', 1, 'uploads/download (21).jpeg'),
(13, 4, 0, 'Men Dress', 'Men\'s dress attire exudes sophistication and style, tailored for formal occasions with impeccable craftsmanship and timeless elegance.', 'Men\'s dress', 12.00, 2, '0', 1, 'Dress', '2024-07-06', 1, 'uploads/images (21).jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `quick_confirmation`
--

CREATE TABLE `quick_confirmation` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `address` text NOT NULL,
  `payment` varchar(50) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quick_confirmation`
--

INSERT INTO `quick_confirmation` (`id`, `first_name`, `email`, `mobile`, `state`, `city`, `address`, `payment`, `subtotal`, `total`, `created_at`) VALUES
(1, 'G.hussan', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 120.00, 130.00, '2024-07-10 06:31:21'),
(2, 'SHAMAN ALI ', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 120.00, 130.00, '2024-07-10 06:33:47'),
(3, 'SHAMAN ALI ', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 120.00, 130.00, '2024-07-10 06:34:11'),
(4, 'SHAMAN ALI ', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 120.00, 130.00, '2024-07-10 06:34:26'),
(5, 'shaman', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 120.00, 130.00, '2024-07-10 06:37:57'),
(6, 'shaman', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 120.00, 130.00, '2024-07-10 06:38:42'),
(7, 'SHAMAN ALI ', 'abc@gmail.com', '+923082731788', 'punjab', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 120.00, 130.00, '2024-07-10 06:39:13'),
(8, 'SHAMAN ALI ', 'abc@gmail.com', '+923082731788', 'punjab', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 120.00, 130.00, '2024-07-10 06:45:14'),
(9, 'shaman', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 120.00, 130.00, '2024-07-10 06:48:18'),
(10, 'shaman', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 06:50:47'),
(11, 'shaman', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 06:57:05'),
(12, 'shaman', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 07:00:55'),
(13, 'shaman', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 07:09:02'),
(14, 'shaman', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 07:14:33'),
(15, 'ALi', 'abc@gmail.com', '+923082731788', 'punjab', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 07:16:59'),
(16, 'shaman', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 07:20:36'),
(17, 'shaman', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 07:20:56'),
(18, 'shaman', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 07:28:12'),
(19, 'shamanq q', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 07:37:38'),
(20, 'shamanq q', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 07:43:19'),
(21, 'shamanq q', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 07:49:24'),
(22, 'shamanq q', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 07:50:04'),
(23, 'shamanq q', 'abc@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 07:56:52'),
(24, 'SHAMAN ALI ', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 123.00, 133.00, '2024-07-10 08:02:19'),
(25, 'SHAMAN ALI ', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 123.00, 133.00, '2024-07-10 08:57:29'),
(26, 'shaman', 'abc@gmail.com', '+923082731788', 'punjaba', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 300.00, 310.00, '2024-07-10 09:00:59'),
(27, 'SHAMAN ALI ', 'abc@gmail.com', '+923183288238', 'sindh', 'Ghotki', 'Mathelo Moomal Ji Mari Ghotki', '0', 123.00, 133.00, '2024-07-10 09:02:17'),
(28, 'shamanq q', 'shaman@gmail.com', '+923183288238', 'sindh', 'Ghotki', 'Mathelo Moomal Ji Mari Ghotki', '0', 123.00, 133.00, '2024-07-10 09:03:33'),
(29, 'SHAMAN ALI ', 'shamanalimahar462@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 120.00, 130.00, '2024-07-10 09:09:14'),
(30, 'abc', 'abc@gmail.com', '+923082731788', 'punjab', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 300.00, 310.00, '2024-07-10 10:14:42'),
(31, 'Areeba', 'kaaliya@gmail.com', '+923082731788', 'sindh', 'Ghotki', 'sau tandojam hyderabad sindh', '0', 200.00, 210.00, '2024-07-10 11:50:37');

-- --------------------------------------------------------

--
-- Table structure for table `quick_order`
--

CREATE TABLE `quick_order` (
  `Q_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `Q_name` varchar(40) NOT NULL,
  `Q_price` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quick_order`
--

INSERT INTO `quick_order` (`Q_id`, `id`, `customer_id`, `Q_name`, `Q_price`) VALUES
(31, 5, 8, 'Smart phone', '123.00'),
(32, 3, 8, 'Neck less', '300.00'),
(33, 5, 8, 'Smart phone', '123.00'),
(34, 4, 8, 'kids Dress', '123.00'),
(35, 1, 8, 'Bag', '120.00'),
(36, 3, 8, 'Neck less', '300.00'),
(37, 6, 8, 'Dress', '200.00');

-- --------------------------------------------------------

--
-- Table structure for table `quick_purchase`
--

CREATE TABLE `quick_purchase` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_price` decimal(10,2) NOT NULL,
  `product_quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `quick_purchase`
--

INSERT INTO `quick_purchase` (`id`, `order_id`, `product_id`, `product_name`, `product_price`, `product_quantity`) VALUES
(1, 12, 6, 'Dress', 200.00, 1),
(2, 13, 6, 'Dress', 200.00, 1),
(3, 14, 6, 'Dress', 200.00, 1),
(4, 15, 6, 'Dress', 200.00, 1),
(5, 16, 6, 'Dress', 200.00, 1),
(6, 17, 6, 'Dress', 200.00, 1),
(7, 18, 6, 'Dress', 200.00, 1),
(8, 19, 6, 'Dress', 200.00, 1),
(9, 20, 6, 'Dress', 200.00, 1),
(10, 21, 6, 'Dress', 200.00, 1),
(11, 22, 6, 'Dress', 200.00, 1),
(12, 23, 6, 'Dress', 200.00, 1),
(13, 24, 5, 'Smart phone', 123.00, 1),
(14, 25, 5, 'Smart phone', 123.00, 1),
(15, 26, 3, 'Neck less', 300.00, 1),
(16, 27, 5, 'Smart phone', 123.00, 1),
(17, 28, 4, 'kids Dress', 123.00, 1),
(18, 29, 1, 'Bag', 120.00, 1),
(19, 30, 3, 'Neck less', 300.00, 1),
(20, 31, 6, 'Dress', 200.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` int(11) NOT NULL,
  `storeName` varchar(255) NOT NULL,
  `storeDescription` text NOT NULL,
  `storeAddress` varchar(255) NOT NULL,
  `storeEmail` varchar(255) NOT NULL,
  `storePhone` varchar(20) NOT NULL,
  `storeImage` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stores`
--

INSERT INTO `stores` (`id`, `storeName`, `storeDescription`, `storeAddress`, `storeEmail`, `storePhone`, `storeImage`, `created_at`) VALUES
(2, 'Daraz', 'Daraz is a leading online marketplace in South Asia, offering a wide range of products including electronics, fashion, beauty, and more, connecting sellers and buyers across multiple countries.', 'sau tandojam hyderabad sindh', 'abc1@gmail.com', '03082731788', 'Store/download.png', '2024-06-08 17:56:54'),
(3, 'Amazon', 'Amazon is a global e-commerce and cloud computing giant, known for its vast online marketplace offering a wide range of products, digital streaming services,cloud technology.', 'Mathelo Moomal Ji Mari Ghotki', 'amazon@gmail.com', '03183288238', 'Store/download (1).png', '2024-06-26 10:04:18'),
(4, 'ebay', 'E-bay is a global e-commerce and cloud computing giant, known for its vast online marketplace offering a wide range of products, digital streaming services,cloud technology.', 'sau tandojam hyderabad sindh', 'ebay@gmail.com', '03082731782', 'Store/download (2).png', '2024-06-26 11:10:24');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `lastname`, `email`, `password`, `phone`) VALUES
(1, 'shaman', 'ali', 'abc@gmail.com', '$2y$10$P6sicJkdsN5hKerFkXvGue3slNDtkT/mlYSUo.VwsVOA84q3J6dk6', '03082731788'),
(2, 'abc', 'cde', 'abcd@gmail.com', '123', '03082731788'),
(3, 'shaman', 'ali', 'new@gmail.com', '12345', '03082731788'),
(4, 'shaman', 'ali', 'shaman2@gmail.com', '123', '03082731788'),
(5, 'shaman', 'ali', 'abc1@gmail.com', '123', '03082731788'),
(6, 'shaman', 'ali', 'sham@gmail.com', '123', '03082731788'),
(8, 'Shaman', 'ali', 'abdulfatahmahar9@gmail.com', '123', '03183288238'),
(9, 'ali', 'abc', 'abcd1@gmail.com', '123', '03183288238'),
(10, 'anc', 'sds', 'sdc@gmail.com', '123', '03183288238');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `added_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `product_name` varchar(255) NOT NULL,
  `product_image` varchar(255) DEFAULT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `stock_status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `product_id`, `customer_id`, `added_on`, `product_name`, `product_image`, `unit_price`, `stock_status`) VALUES
(119, 3, 14, '2024-07-08 07:13:33', 'Neck less', 'uploads/download (2).jpeg', 300.00, NULL),
(120, 1, 14, '2024-07-08 07:15:08', 'Bag', 'uploads/download (13).jpeg', 120.00, NULL),
(121, 3, 8, '2024-07-08 11:00:33', 'Neck less', 'uploads/download (2).jpeg', 300.00, NULL),
(122, 4, 8, '2024-07-08 11:00:53', 'kids Dress', 'uploads/images (15).jpeg', 123.00, NULL),
(123, 3, 16, '2024-07-08 11:47:20', 'Neck less', 'uploads/download (2).jpeg', 300.00, NULL),
(124, 6, 16, '2024-07-10 04:45:02', 'Dress', 'uploads/images (9).jpeg', 200.00, NULL),
(125, 1, 19, '2024-07-10 05:39:32', 'Bag', 'uploads/download (13).jpeg', 120.00, NULL),
(126, 3, 15, '2024-07-10 10:18:30', 'Neck less', 'uploads/download (2).jpeg', 300.00, NULL),
(127, 4, 15, '2024-07-10 10:18:33', 'kids Dress', 'uploads/images (15).jpeg', 123.00, NULL),
(128, 4, 16, '2024-07-10 11:52:53', 'kids Dress', 'uploads/images (15).jpeg', 123.00, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD PRIMARY KEY (`p_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`CategoryId`);

--
-- Indexes for table `checkout`
--
ALTER TABLE `checkout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkout_items`
--
ALTER TABLE `checkout_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `confirm_order`
--
ALTER TABLE `confirm_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quick_confirmation`
--
ALTER TABLE `quick_confirmation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quick_order`
--
ALTER TABLE `quick_order`
  ADD PRIMARY KEY (`Q_id`),
  ADD KEY `id` (`id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `quick_purchase`
--
ALTER TABLE `quick_purchase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `wishlist_ibfk_1` (`customer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cart_items`
--
ALTER TABLE `cart_items`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `CategoryId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `checkout`
--
ALTER TABLE `checkout`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `checkout_items`
--
ALTER TABLE `checkout_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `confirm_order`
--
ALTER TABLE `confirm_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `quick_confirmation`
--
ALTER TABLE `quick_confirmation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `quick_order`
--
ALTER TABLE `quick_order`
  MODIFY `Q_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `quick_purchase`
--
ALTER TABLE `quick_purchase`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart_items`
--
ALTER TABLE `cart_items`
  ADD CONSTRAINT `cart_items_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`user_id`);

--
-- Constraints for table `quick_order`
--
ALTER TABLE `quick_order`
  ADD CONSTRAINT `quick_order_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`user_id`);

--
-- Constraints for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD CONSTRAINT `wishlist_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

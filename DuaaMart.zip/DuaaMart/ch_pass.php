<?php
session_start();
include('db.php'); // Assuming this file connects to your database

if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit;
}

$session = $_SESSION['email'];
$query = "SELECT * FROM customers WHERE email=?";
$stmt = $con->prepare($query);
$stmt->bind_param("s", $session);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

$first_name = htmlspecialchars($row['first_name']);
$last_name = htmlspecialchars($row['last_name']);
$email = htmlspecialchars($row['email']);
$phone = htmlspecialchars($row['phone']);
$address = htmlspecialchars($row['address']);
$image_path = htmlspecialchars($row['image_path']);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Duaa Mart</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <style type="text/css">
        .main-body {
            padding: 15px;
        }
        .card {
            box-shadow: 0 1px 3px 0 rgba(0,0,0,.1), 0 1px 2px 0 rgba(0,0,0,.06);
            position: relative;
            display: flex;
            flex-direction: column;
            min-width: 0;
            word-wrap: break-word;
            background-color: #fff;
            background-clip: border-box;
            border: 0 solid rgba(0,0,0,.125);
            border-radius: .25rem;
        }
        .card-body {
            flex: 1 1 auto;
            min-height: 1px;
            padding: 1rem;
        }
        .gutters-sm {
            margin-right: -8px;
            margin-left: -8px;
        }
        .gutters-sm>.col, .gutters-sm>[class*=col-] {
            padding-right: 8px;
            padding-left: 8px;
        }
        .mb-3, .my-3 {
            margin-bottom: 1rem!important;
        }
        .bg-gray-300 {
            background-color: #e2e8f0;
        }
        .h-100 {
            height: 100%!important;
        }
        .shadow-none {
            box-shadow: none!important;
        }
    </style>
</head>

<body>
    <!-- Topbar Start -->
    <?php include('section/c_header.php'); ?>
    <!-- Navbar End -->

    <div class="container">
        <div class="main-body">
            <!-- Breadcrumb -->
            <nav aria-label="breadcrumb" class="main-breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0)">User</a></li>
                    <li class="breadcrumb-item active" aria-current="page">User Profile</li>
                </ol>
            </nav>
            <!-- /Breadcrumb -->

            <div class="row gutters-sm">
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex flex-column align-items-center text-center">
                                <img src="<?php echo $image_path; ?>" alt="<?php echo $first_name; ?>" width="130px" height="100px">
                                <div class="mt-3">
                                    <h2><?php echo $first_name; ?> <?php echo $last_name; ?></h2>
                                    
                                    <p class="text-muted font-size-sm"><?php echo $address; ?></p>
                                    <button class="btn btn-primary">Follow</button>
                                    <button class="btn btn-outline-primary">Message</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card mt-3">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <div class="col-lg-4 col-6 text-right">
                <p class="m-0"></p>
                <h5 class="m-0 dropdown">
                    <a class="dropdown-toggle" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Manage Profile
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                        <a class="dropdown-item" href="Passwrod.php">Forgot Password</a>
                        <a class="dropdown-item" href="ch_pass.php">Change Password</a>
                        <a class="dropdown-item" href="update.php">Update Profile</a>
                    </div>
                </h5>
            </div>
                                <!-- <h6 class="mb-0">Website</h6> -->
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <div class="col-lg-4 col-6 text-justify">
                <p class="m-0"></p>
                <h5 class="m-0 dropdown" style="width:170px;">
                    <a class=""  href="" role="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        My wishlist
                    </a>
                </h5>
            </div>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <div class="col-lg-4 col-6 text-justify">
                <p class="m-0"></p>
                <h5 class="m-0 dropdown" style="width:170px;">
                    <a class=""  href="" role="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        My Carts
                    </a>
                </h5>
            </div>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                               <div class="col-lg-4 col-6 text-justify">
                <p class="m-0"></p>
                <h5 class="m-0 dropdown" style="width:170px;">
                    <a class=""  href="" role="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        My Orders
                    </a>
                </h5>
            </div>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                               <div class="col-lg-4 col-6 text-justify">
                <p class="m-0"></p>
                <h5 class="m-0 dropdown" style="width:170px;">
                    <a class=""  href="" role="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Delete Account
                    </a>
                </h5>
            </div>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                               <div class="col-lg-4 col-6 text-justify">
                <p class="m-0"></p>
                <h5 class="m-0 dropdown" style="width:170px;">
                    <a class=""  href="" role="button"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        logout
                    </a>
                </h5>
            </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- change password -->
    <?php

    if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
}
?>

<form action="" method="post">
    <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
    <input type="password" name="oldpassword" placeholder="Enter Your Old password" required>
    <br><br>
    <input type="password" name="newpassword" placeholder="Enter Your New password" required>
    <br><br>
    <input type="password" name="confirmpassword" placeholder="Enter your confirm password" required>
    <br><br>
    <input type="submit" name="submit" value="Change Password">
</form>

<?php
if (isset($_POST['submit'])) {
    $user_id = $_POST['user_id'];
    $oldpassword = $_POST['oldpassword'];
    $newpass = $_POST['newpassword'];
    $confirmpass = $_POST['confirmpassword'];

    // Check if old password matches
    $query = "SELECT * FROM customers WHERE user_id='$user_id' AND password='$oldpassword'";
    $run = mysqli_query($con, $query);
    $check = mysqli_num_rows($run);

    if ($check > 0) {
        if ($newpass !== $confirmpass) {
            echo "Please check your input. New password and confirm password do not match.";
        } else {
            // Update the password
            $update = "UPDATE customers SET password='$newpass' WHERE user_id='$user_id'";
            $run = mysqli_query($con, $update);

            if ($run) {
                
                echo "<script>
                alert('Password updated successfully.');
                window.location.href = 'profile.php';
              </script>";
                exit();
            } else {
                echo "Error updating password. Please try again.";
            }
        }
    } else {
        echo "Old password does not match. Please try again.";
    }
}
?></div></div></div>

    <!-- Footer Start -->
    <?php include('footer/footer.php'); ?>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>

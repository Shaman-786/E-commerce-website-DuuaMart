<?php
session_start();

// Include database connection
include('db.php');

// Function to fetch product details by ID
function getProductDetails($con, $productId) {
    $product = array();

    // Fetch the product details from the database
    $query = "SELECT * FROM products WHERE id = ?";
    if ($stmt = $con->prepare($query)) {
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if a product was found
        if ($result->num_rows > 0) {
            $product = $result->fetch_assoc();
        }
    }

    return $product;
}

// Handle form submission for placing an order
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $first_name = $_POST['first_name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $address = $_POST['address'];
    $payment = $_POST['payment'];
    $subtotal = $_POST['subtotal'];
    $total = $_POST['total'];

    // Insert into quick_confirmation table
    $sql = "INSERT INTO quick_confirmation (first_name, email, mobile, state, city, address, payment, subtotal, total) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ssssssddd", $first_name, $email, $mobile, $state, $city, $address, $payment, $subtotal, $total);

    if ($stmt->execute()) {
        // Retrieve the order ID after successful insertion
        $order_id = $stmt->insert_id;

        // Assuming you get product details directly from form or another source
        $product_id = isset($_POST['product_id']) ? $_POST['product_id'] : null;
        $product_name = isset($_POST['product_name']) ? $_POST['product_name'] : null;
        $product_price = isset($_POST['product_price']) ? $_POST['product_price'] : null;
        $product_quantity = isset($_POST['product_quantity']) ? $_POST['product_quantity'] : null;

        // Insert into quick_purchase table for the product in the order
        $sql = "INSERT INTO quick_purchase (order_id, product_id, product_name, product_price, product_quantity) VALUES (?, ?, ?, ?, ?)";
        $stmt = $con->prepare($sql);
        $stmt->bind_param("iisdi", $order_id, $product_id, $product_name, $product_price, $product_quantity);
        
        if ($stmt->execute()) {
            echo "<script>
                
                window.location.href = 'thank_you.php';
              </script>";
        } else {
            echo "Error inserting product details: " . $stmt->error;
        }
    } else {
        echo "Error inserting order details: " . $stmt->error;
    }

    $stmt->close();
}

// Check if the 'id' parameter is set in the URL
if (isset($_GET['id'])) {
    $productId = $_GET['id'];

    // Fetch product details
    $product = getProductDetails($con, $productId);
} else {
    echo "<p>Product ID is missing.</p>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Duaa Mart</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <!-- Topbar Start -->
    <?php include('header/header.php'); ?>
    <!-- Topbar End -->

    <!-- Breadcrumb Start -->
    <div class="container-fluid">
        <div class="row px-xl-5">
            <div class="col-12">
                <nav class="breadcrumb bg-light mb-30">
                    <a class="breadcrumb-item text-dark" href="#">Home</a>
                    <a class="breadcrumb-item text-dark" href="#">Shop</a>
                    <span class="breadcrumb-item active">Shop Detail</span>
                </nav>
            </div>
        </div>
    </div>
    <!-- Breadcrumb End -->
    
    <!-- Checkout Start -->
    <form action="" method="post">
        <div class="container-fluid">
            <div class="row px-xl-5">
                <div class="col-lg-8">
                    <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Billing Address</span></h5>
                    <div class="bg-light p-30 mb-5">
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label>First Name</label>
                                <input class="form-control" type="text" name="first_name" placeholder="John" required>
                            </div>
                            <div class="col-md-6 form-group">
                                <label>E-mail</label>
                                <input class="form-control" type="email" name="email" placeholder="example@email.com" required>
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Mobile No</label>
                                <input class="form-control" type="text" name="mobile" placeholder="+123 456 789" required>
                            </div>
                            <div class="col-md-6 form-group">
                                <label>State</label>
                                <input class="form-control" type="text" name="state" placeholder="State" required>
                            </div>
                            <div class="col-md-6 form-group">
                                <label>City</label>
                                <input class="form-control" type="text" name="city" placeholder="City" required>
                            </div>
                            <div class="col-md-6 form-group">
                                <label>Address</label>
                                <input class="form-control" type="text" name="address" placeholder="123 Street" required>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Order Total</span></h5>
                    <div class="bg-light p-30 mb-5">
                        <div class="border-bottom">
                            <h6 class="mb-3">Products</h6>
                            <div class="d-flex justify-content-between">
                                <p><?php echo isset($product['productName']) ? $product['productName'] : 'Product Name'; ?></p>
                                <p>$<?php echo isset($product['productPrice']) ? $product['productPrice'] : '0.00'; ?></p>
                                <input type="hidden" name="product_id" value="<?php echo isset($product['id']) ? $product['id'] : ''; ?>">
                                <input type="hidden" name="product_name" value="<?php echo isset($product['productName']) ? $product['productName'] : ''; ?>">
                                <input type="hidden" name="product_price" value="<?php echo isset($product['productPrice']) ? $product['productPrice'] : ''; ?>">
                                <input type="hidden" name="product_quantity" value="1"> <!-- Assuming default quantity is 1 -->
                            </div>
                        </div>
                        <div class="border-bottom pt-3 pb-2">
                            <div class="d-flex justify-content-between mb-3">
                                <h6>Subtotal</h6>
                                <h6>$<?php echo isset($product['productPrice']) ? $product['productPrice'] : '0.00'; ?></h6>
                                <input type="hidden" name="subtotal" value="<?php echo isset($product['productPrice']) ? $product['productPrice'] : '0.00'; ?>">
                            </div>
                            <div class="d-flex justify-content-between">
                                <h6 class="font-weight-medium">Shipping</h6>
                                <h6 class="font-weight-medium">$10</h6>
                            </div>
                        </div>
                        <div class="pt-2">
                            <div class="d-flex justify-content-between mt-2">
                                <h5>Total</h5>
                                <h5>$<?php echo isset($product['productPrice']) ? ($product['productPrice'] + 10) : '10.00'; ?></h5>
                                <input type="hidden" name="total" value="<?php echo isset($product['productPrice']) ? ($product['productPrice'] + 10) : '10.00'; ?>">
                            </div>
                        </div>
                    </div>
                    <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Payment Method</span></h5>
                    <div class="bg-light p-30">
                        <div class="form-group">
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" name="payment" id="paypal" value="Paypal" required>
                                <label class="custom-control-label" for="paypal">Paypal</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" name="payment" id="directcheck" value="Direct Check" required>
                                <label class="custom-control-label" for="directcheck">Direct Check</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" name="payment" id="cashondelivery" value="Cash On Delivery" required>
                                <label class="custom-control-label" for="cashondelivery">Cash On Delivery</label>
                            </div>
                        </div>
                        <div class="form-group mb-4">
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" name="payment" id="banktransfer" value="Bank Transfer" required>
                                <label class="custom-control-label" for="banktransfer">Bank Transfer</label>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-block btn-primary font-weight-bold py-3" name="place_order">Place Order</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <!-- Checkout End -->

    <!-- Footer Start -->
    <?php include('footer/footer.php'); ?>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>
</html>

<?php
// Close the database connection
$con->close();
?>

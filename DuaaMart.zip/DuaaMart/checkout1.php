<?php
// Include the database connection
include('db.php');

// Start session (if not already started)
session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming your form fields are named appropriately
    $firstName = $_POST['first_name'];
    $email = $_POST['email'];
    $mobileNo = $_POST['mobile_no'];
    $address = $_POST['address'];
    $zipCode = $_POST['zip_code'];
    $paymentMethod = $_POST['payment'];

    // Insert into checkout_items table from session cart items
    if (isset($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $cartItem) {
            $p_id = $cartItem['p_id'];
            $p_name = $cartItem['p_name'];
            $price = $cartItem['price'];
            $quantity = $cartItem['quantity'];

            // Prepare and execute SQL insert statement
            $query = "INSERT INTO checkout_items (p_id, p_name, price, quantity) VALUES (?, ?, ?, ?)";
            $stmt = $con->prepare($query);
            $stmt->bind_param("issi", $p_id, $p_name, $price, $quantity);
            $stmt->execute();
        }

        // Clear the cart after checkout
        unset($_SESSION['cart']);
    }

    // Additional logic for order processing can go here

    // Redirect or show success message
    header("Location: order_success.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Include your head content here -->
</head>
<body>
    <!-- Include your header and breadcrumb here -->

    <!-- Checkout Form Start -->
    <form action="checkout.php" method="post">
        <!-- Billing Address Section -->
        <div class="container-fluid">
            <div class="row px-xl-5">
                <div class="col-lg-8">
                    <!-- Billing Address fields -->
                    <!-- Example: -->
                    <input type="text" name="first_name" placeholder="First Name" required>
                    <input type="text" name="email" placeholder="Email" required>
                    <!-- Add other fields as needed -->
                </div>
                <div class="col-lg-4">
                    <!-- Order Total Section -->
                    <div class="bg-light p-30 mb-5">
                        <!-- Display cart items and total dynamically -->
                        <?php
                        $subtotal = 0;
                        if (isset($_SESSION['cart'])) {
                            foreach ($_SESSION['cart'] as $cartItem) {
                                $subtotal += $cartItem['price'] * $cartItem['quantity'];
                                echo "<div class='d-flex justify-content-between'>
                                        <p>{$cartItem['p_name']}</p>
                                        <p>{$cartItem['price']}</p>
                                      </div>";
                            }
                        }
                        ?>
                        <!-- Display subtotal and total -->
                        <div class="d-flex justify-content-between mb-3">
                            <h6>Subtotal</h6>
                            <h6>$<?php echo number_format($subtotal, 2); ?></h6>
                        </div>
                        <div class="d-flex justify-content-between">
                            <h6 class="font-weight-medium">Shipping</h6>
                            <h6 class="font-weight-medium">$10</h6>
                        </div>
                        <div class="pt-2">
                            <div class="d-flex justify-content-between mt-2">
                                <h5>Total</h5>
                                <h5>$<?php echo number_format($subtotal + 10, 2); ?></h5>
                            </div>
                        </div>
                    </div>
                    <!-- Payment Section -->
                    <div class="bg-light p-30">
                        <!-- Payment method selection -->
                        <div class="form-group">
                            <div class="custom-control custom-radio">
                                <input type="radio" class="custom-control-input" name="payment" id="paypal" value="paypal">
                                <label class="custom-control-label" for="paypal">Paypal</label>
                            </div>
                            <!-- Add other payment options -->
                        </div>
                        <button type="submit" class="btn btn-block btn-primary font-weight-bold py-3">Place Order</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <!-- Checkout Form End -->

    <!-- Include your footer and scripts here -->
</body>
</html>

<?php
session_start();

// Include database connection
include('db.php');

// Initialize variables
$product = null;
$wishlist_count = 0;
$count = 0;

// Function to fetch product details
function getProductDetails($con, $productId) {
    $query = "SELECT * FROM products WHERE id = ?";
    if ($stmt = $con->prepare($query)) {
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    } else {
        return null;
    }
}

// Function to count wishlist items
function getWishlistCount($con) {
    $sql = "SELECT COUNT(*) as count FROM wishlist";
    $result = $con->query($sql);
    if ($result !== false) {
        return $result->fetch_assoc()['count'];
    } else {
        return 0;
    }
}

// Function to count cart items
function getCartCount($con) {
    $query = "SELECT COUNT(*) AS count FROM cart_items";
    $result = $con->query($query);
    if ($result !== false) {
        return $result->fetch_assoc()['count'];
    } else {
        return 0;
    }
}

// Check if the 'id' parameter is set in the URL
if (isset($_GET['id'])) {
    $productId = $_GET['id'];
    $product = getProductDetails($con, $productId);
    if (!$product) {
        echo "<p>Product not found.</p>";
        exit();
    }
} else {
    echo "<p>Product ID is missing.</p>";
    exit();
}

// Handle form submission for adding to cart or quick order
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if Add to Cart or Buy Now was clicked
    if (isset($_POST['add_to_cart']) || isset($_POST['BuyNow'])) {
        $product_id = $_POST['product_id'];
        $product_name = $_POST['product_name'];
        $product_price = $_POST['product_price'];
        $customerId = $_SESSION['customer_id'] ?? null; // Use null if customer_id is not set
        $image = ''; // Adjust based on your product data structure

        if ($customerId === null) {
            echo "<script>
                    alert('You must be logged in to perform this action.');
                    window.location.href = 'login.php';
                  </script>";
            exit();
        }

        if (isset($_POST['add_to_cart'])) {
            // Insert into cart_items table
            $query = "INSERT INTO cart_items (p_id, customer_id, p_name, price, image) VALUES (?, ?, ?, ?, ?)";
            if ($stmt = $con->prepare($query)) {
                $stmt->bind_param('iissd', $product_id, $customerId, $product_name, $product_price, $image);
                if ($stmt->execute()) {
                    echo "<script>
                            alert('Data successfully added to cart');
                            window.location.href = 'cart.php';
                          </script>";
                    exit();
                } else {
                    echo "<p>Error adding to cart.</p>";
                }
            } else {
                echo "<p>Database query failed.</p>";
            }
        } elseif (isset($_POST['BuyNow'])) {
            // Insert into quick_order table
            $query = "INSERT INTO quick_order (Q_id, id, Q_name, Q_price, customer_id) VALUES (NULL, ?, ?, ?, ?)";
            if ($stmt = $con->prepare($query)) {
                $stmt->bind_param('issd', $product_id, $product_name, $product_price, $customerId);
                if ($stmt->execute()) {
                    header('Location: Order.php?id=' . $product_id . '&name=' . urlencode($product_name) . '&price=' . $product_price);
                    exit();
                } else {
                    echo "<p>Error processing quick order.</p>";
                }
            } else {
                echo "<p>Database query failed.</p>";
            }
        }
    }
}

// Fetch counts
$wishlist_count = getWishlistCount($con);
$count = getCartCount($con);

// Close the database connection
$con->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Duaa Mart</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">
    <link href="img/favicon.ico" rel="icon">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
          <!-- Topbar Start -->
    <div class="container-fluid">
        
        <div class="row align-items-center bg-light py-3 px-xl-5 d-none d-lg-flex">
            <div class="col-lg-4">
                <a href="" class="text-decoration-none">
                    <span class="h1 text-uppercase text-primary bg-dark px-2">Duaa</span>
                    <span class="h1 text-uppercase text-dark bg-primary px-2 ml-n1">Mart</span>
                </a>
            </div>
            <div class="col-lg-4 col-6 text-left">
                <form action="">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search for products">
                        <div class="input-group-append">
                            <span class="input-group-text bg-transparent text-primary">
                                <i class="fa fa-search"></i>
                            </span>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-4 col-6 text-right">
                <p class="m-0">Customer Service</p>
                <h5 class="m-0">+92 318 3288 238</h5>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid bg-dark mb-30">
        <div class="row px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a class="btn d-flex align-items-center justify-content-between bg-primary w-100" data-toggle="collapse" href="#navbar-vertical" style="height: 65px; padding: 0 30px;">
                    <h6 class="text-dark m-0"><i class="fa fa-bars mr-2"></i>Categories</h6>
                    <i class="fa fa-angle-down text-dark"></i>
                </a>
                <nav class="collapse position-absolute navbar navbar-vertical navbar-light align-items-start p-0 bg-light" id="navbar-vertical" style="width: calc(100% - 30px); z-index: 999;">
                    <div class="navbar-nav w-100">
                        <a href="Mobile.php" class="nav-item nav-link">Mobile</a>
                        <a href="Computer.php" class="nav-item nav-link">Computer</a>
                        <a href="Jewelry.php" class="nav-item nav-link">Jewelry</a>
                         <a href="men.php" class="nav-item nav-link">Men</a>
                         <a href="Women.php" class="nav-item nav-link">Women</a>
                         <a href="kids.php" class="nav-item nav-link">Kids</a>
                </nav>
            </div>
            <div class="col-lg-9">
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-0">
                    <a href="" class="text-decoration-none d-block d-lg-none">
                        <span class="h1 text-uppercase text-dark bg-light px-2">Duaa</span>
                        <span class="h1 text-uppercase text-light bg-primary px-2 ml-n1">Mart</span>
                    </a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto py-0">
                            <a href="index.php" class="nav-item nav-link">Home</a>
                            <a href="about.php" class="nav-item nav-link">About us</a>
                          
                            <a href="Product.php" class="nav-item nav-link">Products</a>
                            <a href="store.php" class="nav-item nav-link">Store</a>
                            <a href="contact.php" class="nav-item nav-link">Contact</a>

                        </div> </div>
                             
                            <div class="navbar-nav ml-auto py-0 d-none d-lg-block">
                                <a href="#" class="btn px-0">
        <!-- <i class="fas fa-heart text-primary"></i> -->
        

    <a href="wishlist.php" class="btn px-0">
        <i class="fas fa-heart text-primary"></i>
        <span class="badge text-secondary border border-secondary rounded-circle" style="padding-bottom: 2px;"><?php echo $wishlist_count; ?></span>
    </a>
                                <a href="cart.php" class="btn px-0 ml-3">
        <i class="fas fa-shopping-cart text-primary"></i>
        
        <span class="badge text-secondary border border-secondary rounded-circle" style="padding-bottom: 2px;"><?php echo $count; ?></span>
    </a>
                                
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Navbar End -->

        <!-- Breadcrumb Start -->
        <div class="container-fluid">
            <div class="row px-xl-5">
                <div class="col-12">
                    <nav class="breadcrumb bg-light mb-30">
                        <a class="breadcrumb-item text-dark" href="index.php">Home</a>
                        <a class="breadcrumb-item text-dark" href="Product.php">Product</a>
                        <span class="breadcrumb-item active">Product Detail</span>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Breadcrumb End -->

        <!-- Product Details -->
       <!-- Product Details -->
                    <div class="container-fluid pb-5">
                        <div class="row px-xl-5">
                            <!-- Product Image Carousel -->
                            <div class="col-lg-5 mb-30">
                                <div id="product-carousel" class="carousel slide" data-ride="carousel">
                                    <div class="carousel-inner bg-light">
                                        <div class="carousel-item active">
                                            <img class="w-100 h-100" src="<?php echo isset($product['p_img']) ? "../multishop/dashmin/" . $product['p_img'] : 'default.jpg'; ?>" alt="<?php echo isset($product['productName']) ? $product['productName'] : 'Product Image'; ?>">
                                        </div>
                                        <!-- Add more carousel items here if needed -->
                                    </div>
                                    <a class="carousel-control-prev" href="#product-carousel" data-slide="prev">
                                        <i class="fa fa-2x fa-angle-left text-dark"></i>
                                    </a>
                                    <a class="carousel-control-next" href="#product-carousel" data-slide="next">
                                        <i class="fa fa-2x fa-angle-right text-dark"></i>
                                    </a>
                                </div>
                            </div>

                            <!-- Product Information -->
                            <div class="col-lg-7 h-auto mb-30">
                                <div class="h-100 bg-light p-30">
                                    <h3><?php echo isset($product['productName']) ? $product['productName'] : 'Product Name'; ?></h3>
                                    <div class="d-flex mb-3">
                                        <div class="text-primary mr-2">
                                            <small class="fas fa-star"></small>
                                            <small class="fas fa-star"></small>
                                            <small class="fas fa-star"></small>
                                            <small class="fas fa-star-half-alt"></small>
                                            <small class="far fa-star"></small>
                                        </div>
                                        <small class="pt-1">(99 Reviews)</small>
                                    </div>
                                    <h3 class="font-weight-semi-bold mb-4">$<?php echo isset($product['productPrice']) ? $product['productPrice'] : '0.00'; ?></h3>
                                    <p class="mb-4"><?php echo isset($product['productDescription']) ? $product['productDescription'] : 'Product Description'; ?></p>

                                    <!-- Quantity Selector and Form -->
                                    <div class="d-flex align-items-center mb-4 pt-2">
                                        <div class="input-group quantity mr-3" style="width: 130px;">
                                            <div class="input-group-btn">
                                                <button class="btn btn-primary btn-minus">
                                                    <i class="fa fa-minus"></i>
                                                </button>
                                            </div>
                                            <input type="text" class="form-control bg-secondary border-0 text-center" value="1">
                                            <div class="input-group-btn">
                                                <button class="btn btn-primary btn-plus">
                                                    <i class="fa fa-plus"></i>
                                                </button>
                                            </div>
                                        </div>
                                        <form method="post" action="">
                                            <input type="hidden" name="product_id" value="<?php echo isset($product['id']) ? $product['id'] : ''; ?>">
                                            <input type="hidden" name="product_name" value="<?php echo isset($product['productName']) ? $product['productName'] : ''; ?>">
                                            <input type="hidden" name="product_price" value="<?php echo isset($product['productPrice']) ? $product['productPrice'] : ''; ?>">
                                            <button type="submit" name="add_to_cart" class="btn btn-primary px-3"><i class="fa fa-shopping-cart mr-1"></i> Add To Cart</button>
                                            <button type="submit" name="BuyNow" class="btn btn-primary px-3"><i class="far fa-credit-card"></i>&nbsp Buy Now</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Footer -->
                    <?php include('footer/footer.php'); ?>

                    <!-- Back to Top Button -->
                    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

                    <!-- JavaScript Libraries -->
                    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
                    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
                    <script src="lib/easing/easing.min.js"></script>
                    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

                    <!-- Contact Form Scripts -->
                    <script src="mail/jqBootstrapValidation.min.js"></script>
                    <script src="mail/contact.js"></script>

                    <!-- Custom Script -->
                    <script src="js/main.js"></script>

                </body>
                </html>
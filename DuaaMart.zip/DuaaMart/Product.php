<?php
session_start();

// Include database connection
include('db.php');

// Handle adding to wishlist
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_wishlist'])) {
    $productId = $_POST['product_id'];

    // Check if customer_id is set in session (assuming customer_id is 15 for testing)
    $customerId = 15; // Replace with $_SESSION['customer_id'] in production

    // Fetch product details from products table
    $sql = "SELECT * FROM products WHERE id = ?";
    $stmt = $con->prepare($sql);

    if ($stmt) {
        $stmt->bind_param('i', $productId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $productName = $row['productName'];
            $productImg = $row['p_img'];
            $productPrice = $row['productPrice'];

            // Insert product into wishlist table
            $sqlInsert = "INSERT INTO wishlist (customer_id, product_id, product_name, product_image, unit_price) 
                          VALUES (?, ?, ?, ?, ?)";
            $stmtInsert = $con->prepare($sqlInsert);

            if ($stmtInsert) {
                $stmtInsert->bind_param('iisss', $customerId, $productId, $productName, $productImg, $productPrice);

                if ($stmtInsert->execute()) {
                    echo "<script>alert('Product added to wishlist.');</script>";
                } else {
                    echo "<script>alert('Failed to add product to wishlist: " . $stmtInsert->error . "');</script>";
                }
                $stmtInsert->close();
            } else {
                echo "<script>alert('Failed to prepare statement for inserting into wishlist: " . $con->error . "');</script>";
            }
        } else {
            echo "<script>alert('Product not found.');</script>";
        }
        $stmt->close();
    } else {
        echo "<script>alert('Failed to prepare statement for fetching product details: " . $con->error . "');</script>";
    }
}

// Handle adding to cart
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    // Retrieve form data safely
    $product_id = $_POST['product_id'];
    $product_name = isset($_POST['product_name']) ? $_POST['product_name'] : '';
    $product_price = isset($_POST['product_price']) ? $_POST['product_price'] : '';
    $customer_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
    $image = ''; // Assuming image handling is not implemented here

    // Validate customer_id
    if ($customer_id === null) {
        echo "<script>alert('Please login to add products to your cart.');</script>";
    } else {
        // Check if the product is already in the cart for this customer
        $checkQuery = "SELECT * FROM cart_items WHERE p_id = ? AND customer_id = ?";
        $stmtCheck = $con->prepare($checkQuery);

        if ($stmtCheck) {
            $stmtCheck->bind_param('ii', $product_id, $customer_id);
            $stmtCheck->execute();
            $stmtCheck->store_result();

            if ($stmtCheck->num_rows > 0) {
                echo "<script>alert('Product already in your cart.');</script>";
            } else {
                // Insert into cart_items table
                $insertQuery = "INSERT INTO cart_items (p_id, customer_id, p_name, price, image) VALUES (?, ?, ?, ?, ?)";
                $stmtInsert = $con->prepare($insertQuery);

                if ($stmtInsert) {
                    $stmtInsert->bind_param('iisss', $product_id, $customer_id, $product_name, $product_price, $image);

                    if ($stmtInsert->execute()) {
                        echo "<script>
                                alert('Data successfully added to cart');
                                window.location.href = 'cart.php';
                              </script>";
                        exit();
                    } else {
                        echo "<script>alert('Error adding to cart: " . $stmtInsert->error . "');</script>";
                    }
                    $stmtInsert->close();
                } else {
                    echo "<script>alert('Failed to prepare statement for adding to cart: " . $con->error . "');</script>";
                }
            }
        } else {
            echo "<script>alert('Database query failed while checking cart: " . $con->error . "');</script>";
        }
    }
}

// Fetch products from database based on the query
$query = "SELECT * FROM products";

// Check if the price range is selected
if (isset($_GET['price_range']) && !empty($_GET['price_range'])) {
    $priceRanges = $_GET['price_range'];
    $conditions = [];

    foreach ($priceRanges as $range) {
        list($minPrice, $maxPrice) = explode('-', $range);
        $conditions[] = "(productPrice BETWEEN $minPrice AND $maxPrice)";
    }

    // Join conditions with OR operator
    if (!empty($conditions)) {
        $query .= " WHERE " . implode(' OR ', $conditions);
    }
}

$result = mysqli_query($con, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Duaa Mart</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">
    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
   <?php include('header/header.php'); ?>

    <!-- Breadcrumb Start -->
    <div class="container-fluid">
        <div class="row px-xl-5">
            <div class="col-12">
                <nav class="breadcrumb bg-light mb-30">
                    <a class="breadcrumb-item text-dark" href="index.php">Home</a>
                    <a class="breadcrumb-item text-dark" href="Product.php">Products</a>
                    <span class="breadcrumb-item active">Product list</span>
                </nav>
            </div>
        </div>
    </div>
    <!-- Breadcrumb End -->

    <!-- Shop Start -->
    <div class="container-fluid">
        <div class="row px-xl-5">
            <!-- Shop Sidebar Start -->
            <div class="col-lg-3 col-md-4">
                <!-- Price Start -->
                <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Filter by price</span></h5>
                <div class="bg-light p-4 mb-30">
                    <form method="GET" action="">
                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                            <input type="checkbox" class="custom-control-input" name="price_range[]" value="0-100" id="price-1">
                            <label class="custom-control-label" for="price-1">$0 - $100</label>
                            <span class="badge border font-weight-normal">150</span>
                        </div>
                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                            <input type="checkbox" class="custom-control-input" name="price_range[]" value="100-200" id="price-2">
                            <label class="custom-control-label" for="price-2">$100 - $200</label>
                            <span class="badge border font-weight-normal">295</span>
                        </div>
                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                            <input type="checkbox" class="custom-control-input" name="price_range[]" value="200-300" id="price-3">
                            <label class="custom-control-label" for="price-3">$200 - $300</label>
                            <span class="badge border font-weight-normal">246</span>
                        </div>
                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">
                            <input type="checkbox" class="custom-control-input" name="price_range[]" value="300-400" id="price-4">
                            <label class="custom-control-label" for="price-4">$300 - $400</label>
                            <span class="badge border font-weight-normal">145</span>
                        </div>
                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between">
                            <input type="checkbox" class="custom-control-input" name="price_range[]" value="400-500" id="price-5">
                            <label class="custom-control-label" for="price-5">$400 - $500</label>
                            <span class="badge border font-weight-normal">168</span>
                        </div>
                        <button type="submit" class="btn btn-primary mt-3">Filter</button>
                    </form>
                </div>
                <!-- Price End -->
            </div>
            <?php 
// Handle search query
if (isset($_GET['submit_search'])) {
    // Get the search query
    $search_query = $_GET['search_query'];
    // Prepare SQL query to search by product name
    $sql = "SELECT * FROM products WHERE productName LIKE '%$search_query%'";
    // Execute SQL query
    $result = mysqli_query($con, $sql);
    // Check if results found
    if ($result && $result->num_rows > 0) {
        // Products found, display them
        while ($row = $result->fetch_assoc()) {
            $productId = $row['id'];
            $productName = $row['productName'];
            $productPrice = $row['productPrice'];
            $productDescription = $row['productDescription'];
            $productImg = $row['p_img'];
            echo '<div class="product-item bg-light mb-4 text-center">';
            echo '<div class="product-img position-relative overflow-hidden">';

            
            echo '<img src="../multishop/dashmin/' . $productImg . '" alt="' . $productName . '" style="width: 280px; height:240px;">';
            echo '<h4>' . $productName . '</h4>';
            echo '<p>' . $productDescription . '</p>';
            echo '<div>$' . $productPrice . '</div>';
            echo '</div>';
            echo '</div>';
            
        }
    } else {
        // No products found
        echo "<p>No products found.</p>";
    }
} else {
    // Execute main product query
    $result = mysqli_query($con, $query);
} ?>

            <!-- Shop Sidebar End -->

            <!-- Shop Product Start -->
            <div class="col-lg-9 col-md-8">
                <div class="container">
                    <div class="row pb-3">
                        <div class="col-12 pb-1">
                            <div class="d-flex align-items-center justify-content-between mb-4">
                                <div>
                                    <!-- Sorting dropdown -->
                                </div>
                                <div class="ml-2">
                                    <!-- View options -->
                                </div>
                            </div>
                        </div>

                        <!-- Display fetched products -->
                        <?php
                        if ($result && $result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $productId = $row['id'];
                                $productName = $row['productName'];
                                $productPrice = $row['productPrice'];
                                $productDescription = $row['productDescription'];
                                $productImg = $row['p_img'];
                                ?>
                                <div class="col-lg-4 col-md-6 col-sm-6 pb-1">
                                    <div class="product-item bg-light mb-4">
                                        <div class="product-img position-relative overflow-hidden">
                                            <a href="detail.php?id=<?php echo $productId; ?>">
                                                <img src="../multishop/dashmin/<?php echo $productImg; ?>" alt="<?php echo $productName; ?>" style="width: 280px; height:240px;">
                                            </a>
                                        </div>
                                        <div class="position-relative">
                                            <h3 class="text-center"><a href="detail.php?id=<?php echo $productId; ?>" class="text-dark"><?php echo $productName; ?></a></h3>
                                            <div class="d-flex align-items-center justify-content-center">
                                                <span class="text-secondary font-weight-normal mr-1"></span>
                                                <span class="text-dark font-weight-bold">$<?php echo $productPrice; ?></span>
                                            </div>
                                            <div class="d-flex flex-row align-items-center">
                                                <form method="POST" action="" style="display:inline;">
                                                    <input type="hidden" name="product_id" value="<?php echo $productId; ?>">
                                                    <button type="submit" name="add_to_wishlist" class="btn btn-outline-danger px-3 btn-square">
                                                        <i class="fa fa-heart mr-1"></i>
                                                    </button>
                                                </form>
                                                <div class="flex-grow-1"></div> <!-- Flexible spacer -->
                                                <form method="POST" action="login.php">
                                                    <input type="hidden" name="product_id" value="<?php echo $productId; ?>">
                                                    <input type="hidden" name="product_name" value="<?php echo $productName; ?>">
                                                    <input type="hidden" name="product_price" value="<?php echo $productPrice; ?>">
                                                    <button type="submit" name="add_to_cart" class="btn btn-primary px-3"><i class="fa fa-shopping-cart mr-1"></i></button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                        } else {
                            echo "<div class='col-12'><p>No products found.</p></div>";
                        }
                        ?>
                    </div>
                </div>
            </div>
            <!-- Shop Product End -->
        </div>
    </div>
    <!-- Shop End -->

    <!-- Footer Start -->
    <?php include('footer/footer.php'); ?>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>


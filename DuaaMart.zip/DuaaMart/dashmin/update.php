<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
            color: #555;
        }

        input[type="text"],
        input[type="number"],
        input[type="file"],
        input[type="date"],
        textarea,
        select {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
            box-sizing: border-box;
        }

        input[type="checkbox"] {
            width: auto;
            margin-right: 10px;
        }

        button {
            padding: 10px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Edit Product</h2>
        <?php
        // Check if product ID is set
        if (isset($_GET['id'])) {
            $id = $_GET['id'];

            // Connect to MySQL database (Change the credentials accordingly)
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "crud";

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Prepare SQL statement to fetch product details
            $sql = "SELECT * FROM products WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();

            // Check if product exists
            if ($result->num_rows > 0) {
                $product = $result->fetch_assoc();
                ?>
                <form id="editProductForm" method="POST" enctype="multipart/form-data" action="">
                    <input type="hidden" name="id" value="<?php echo $product['id']; ?>">

                    <label for="productName">Product Name:</label>
                    <input type="text" id="productName" name="productName" value="<?php echo $product['productName']; ?>" required>

                    <label for="productDescription">Product Description:</label>
                    <textarea id="productDescription" name="productDescription" rows="4" required><?php echo $product['productDescription']; ?></textarea>

                    <label for="productSKU">Product SKU:</label>
                    <input type="text" id="productSKU" name="productSKU" value="<?php echo $product['productSKU']; ?>" required>

                    <label for="productPrice">Product Price ($):</label>
                    <input type="number" id="productPrice" name="productPrice" value="<?php echo $product['productPrice']; ?>" min="0" step="0.01" required>

                    <label for="productStock">Stock Quantity:</label>
                    <input type="number" id="productStock" name="productStock" value="<?php echo $product['productStock']; ?>" min="0" required>

                    <label for="productBrand">Product Brand:</label>
                    <input type="text" id="productBrand" name="productBrand" value="<?php echo $product['productBrand']; ?>" required>

                    <label for="productCategory">Product Category:</label>
                    <select id="productCategory" name="productCategory" required>
                        <option value="electronics" <?php echo ($product['productCategory'] == 'electronics') ? 'selected' : ''; ?>>Electronics</option>
                        <option value="fashion" <?php echo ($product['productCategory'] == 'fashion') ? 'selected' : ''; ?>>Fashion</option>
                        <option value="home" <?php echo ($product['productCategory'] == 'home') ? 'selected' : ''; ?>>Home</option>
                        <option value="books" <?php echo ($product['productCategory'] == 'books') ? 'selected' : ''; ?>>Books</option>
                        <option value="toys" <?php echo ($product['productCategory'] == 'toys') ? 'selected' : ''; ?>>Toys</option>
                    </select>

                    <label for="productTags">Product Tags:</label>
                    <input type="text" id="productTags" name="productTags" value="<?php echo $product['productTags']; ?>" placeholder="Comma separated tags" required>

                    <label for="productReleaseDate">Product Release Date:</label>
                    <input type="date" id="productReleaseDate" name="productReleaseDate" value="<?php echo $product['productReleaseDate']; ?>" required>

                    <label for="productOnSale">On Sale:</label>
                    <input type="checkbox" id="productOnSale" name="productOnSale" <?php echo ($product['productOnSale']) ? 'checked' : ''; ?>>

                    <button type="submit" name="update" style="width:150px;">Update Product</button>
                </form>
                <?php
            } else {
                echo "Product not found.";
            }

            $stmt->close();
            $conn->close();
        } else {
            echo "Product ID is not set.";
        }

        // Check if form is submitted for update
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["update"])) {
            // Retrieve form data
            $id = $_POST["id"];
            $productName = $_POST["productName"];
            $productDescription = $_POST["productDescription"];
            $productSKU = $_POST["productSKU"];
            $productPrice = $_POST["productPrice"];
            $productStock = $_POST["productStock"];
            $productBrand = $_POST["productBrand"];
            $productCategory = $_POST["productCategory"];
            $productTags = $_POST["productTags"];
            $productReleaseDate = $_POST["productReleaseDate"];
            $productOnSale = isset($_POST["productOnSale"]) ? 1 : 0; // Convert checkbox value to 1 or 0

            // Connect to MySQL database (Change the credentials accordingly)
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "crud";

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Prepare SQL statement to update data in products table
            $sql = "UPDATE products SET productName=?, productDescription=?, productSKU=?, productPrice=?, productStock=?, productBrand=?, productCategory=?, productTags=?, productReleaseDate=?, productOnSale=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssdisdssii", $productName, $productDescription, $productSKU, $productPrice, $productStock, $productBrand, $productCategory, $productTags, $productReleaseDate, $productOnSale, $id);

            if ($stmt->execute() === TRUE) {
                echo "Record updated successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }

            // Close connection
            $stmt->close();
            $conn->close();
        }
        ?>
    </div>
</body>
</html>

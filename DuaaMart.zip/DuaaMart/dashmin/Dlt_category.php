<?php
include('db.php');

// Check if ID is set in URL and it's a valid number
if (isset($_GET['CategoryId']) && is_numeric($_GET['CategoryId'])) {
    $CategoryId = $_GET['CategoryId'];

    // Prepare the SQL statement to delete the item from the cart
    $query = "DELETE FROM category WHERE CategoryId = ?";
    $stmt = mysqli_prepare($con, $query);

    // Bind the ID parameter
    mysqli_stmt_bind_param($stmt, 'i', $CategoryId);

    // Execute the statement
    if (mysqli_stmt_execute($stmt)) {
        // Redirect to the cart page with a success message
        header("Location: view_category.php?message=Item removed successfully");
    } else {
        // Redirect to the cart page with an error message
        header("Location: view_category.php?message=Error removing item");
    }

    // Close the statement
    mysqli_stmt_close($stmt);
} else {
    // Redirect to the cart page with an error message if ID is not set or invalid
    header("Location: cart.php?message=Invalid item ID");
}

// Close the database connection
mysqli_close($con);
?>

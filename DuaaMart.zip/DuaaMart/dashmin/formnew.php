<?php include('db.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Product</title>
    <style type="text/css">
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 5px;
            color: #555;
        }

        input[type="text"],
        input[type="number"],
        input[type="file"],
        input[type="date"],
        textarea,
        select {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
            box-sizing: border-box;
        }

        input[type="checkbox"] {
            width: auto;
            margin-right: 10px;
        }

        button {
            padding: 10px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body> 

    <div class="container"><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
        <h2>Add New Product</h2>
        <form id="addProductForm" method="POST" enctype="multipart/form-data" action="">
            <label for="productName">Product Name:</label>
            <input type="text" id="productName" name="productName" required>

            <label for="productDescription">Product Description:</label>
            <textarea id="productDescription" name="productDescription" rows="4" required></textarea>

            <label for="productSKU">Product SKU:</label>
            <input type="text" id="productSKU" name="productSKU" required>

            <label for="productPrice">Product Price ($):</label>
            <input type="number" id="productPrice" name="productPrice" min="0" step="0.01" required>

            <label for="productStock">Stock Quantity:</label>
            <input type="number" id="productStock" name="productStock" min="0" required>

            <label for="productBrand">Product Brand:</label>
            <input type="text" id="productBrand" name="productBrand" required>

            <label for="productCategory">Product Category:</label>
            <select id="productCategory" name="productCategory" required>
                <option value="electronics">Electronics</option>
                <option value="fashion">Fashion</option>
                <option value="home">Home</option>
                <option value="books">Books</option>
                <option value="toys">Toys</option>
            </select>

            <label for="productTags">Product Tags:</label>
            <input type="text" id="productTags" name="productTags" placeholder="Comma separated tags" required>

            <label for="productReleaseDate">Product Release Date:</label>
            <input type="date" id="productReleaseDate" name="productReleaseDate" required>

            <label for="productImage">Product Image:</label>
            <input type="file" id="productImage" name="productImage" accept="image/*" required>

            <label for="productOnSale">On Sale:</label>
            <input type="checkbox" id="productOnSale" value="On Sale:" name="productOnSale" style="width:10px; margin-top: -20px; margin-left:65px;" >

            <button type="submit" style="width:150px;">Add Product</button>
        </form>
        <?php
        // Check if form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Retrieve form data
            $productName = $_POST["productName"];
            $productDescription = $_POST["productDescription"];
            $productSKU = $_POST["productSKU"];
            $productPrice = $_POST["productPrice"];
            $productStock = $_POST["productStock"];
            $productBrand = $_POST["productBrand"];
            $productCategory = $_POST["productCategory"];
            $productTags = $_POST["productTags"];
            $productReleaseDate = $_POST["productReleaseDate"];
            $productOnSale = isset($_POST["productOnSale"]) ? 1 : 0; // Convert checkbox value to 1 or 0

            
            // Prepare SQL statement to insert data into products table
            $sql = "INSERT INTO products (productName, productDescription, productSKU, productPrice, productStock, productBrand, productCategory, productTags, productReleaseDate, productOnSale)
                    VALUES ('$productName', '$productDescription', '$productSKU', $productPrice, $productStock, '$productBrand', '$productCategory', '$productTags', '$productReleaseDate', $productOnSale)";

            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }

            // Close connection
            $conn->close();
        }
        ?>
    </div>
</body>
</html>

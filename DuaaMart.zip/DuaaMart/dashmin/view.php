<?php
include('db.php');

// Retrieving data from the table
$sql = "SELECT * FROM products";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    // Outputting data in a table
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Name</th><th>Description</th><th>SKU</th><th>Price</th><th>Stock</th><th>Brand</th><th>Category</th><th>Tags</th><th>Release Date</th><th>On Sale</th> <th>Action</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>".$row["id"]."</td>";
        echo "<td>".$row["productName"]."</td>";
        echo "<td>".$row["productDescription"]."</td>";
        echo "<td>".$row["productSKU"]."</td>";
        echo "<td>".$row["productPrice"]."</td>";
        echo "<td>".$row["productStock"]."</td>";
        echo "<td>".$row["productBrand"]."</td>";
        echo "<td>".$row["productCategory"]."</td>";
        echo "<td>".$row["productTags"]."</td>";
        echo "<td>".$row["productReleaseDate"]."</td>";
        echo "<td>".$row["productOnSale"]."</td>";
        echo "<td><a href='?delete_product=".$row["id"]."'>Delete</a> | <a href='update.php?id=".$row["id"]."'>Update</a> |  <a href='fromnew.php'>Add New</a></td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

$con->close();
?>



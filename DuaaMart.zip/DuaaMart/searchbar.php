<?php
session_start();

// Include database connection
include('db.php');

// Handle wishlist addition
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_to_wishlist'])) {
    $productId = $_POST['product_id'];
    $customerId = $_SESSION['customer_id'] ?? null; // Use null if customer_id is not set

    if ($customerId !== null) {
        $insertQuery = "INSERT INTO wishlist (customer_id, product_id) VALUES ($customerId, $productId)";

        // Execute the query
        $insertResult = mysqli_query($con, $insertQuery);

        if ($insertResult) {
            echo "<script>alert('Product added to wishlist.');</script>";
        } else {
            echo "<script>alert('Failed to add product to wishlist.');</script>";
        }
    } else {
        echo "<script>alert('Please log in to add products to your wishlist.');</script>";
    }
}

// Handle Add to Cart or Buy Now
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_POST['add_to_cart']) || isset($_POST['BuyNow']))) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $customerId = $_SESSION['customer_id'] ?? null; // Use null if customer_id is not set
    $image = ''; // Adjust based on your product data structure

    if ($customerId !== null) {
        // Check if the product is already in the cart for this customer
        $checkQuery = "SELECT * FROM cart_items WHERE p_id = ? AND customer_id = ?";
        $stmtCheck = $con->prepare($checkQuery);
        
        if ($stmtCheck) {
            $stmtCheck->bind_param('ii', $product_id, $customerId);
            $stmtCheck->execute();
            $stmtCheck->store_result();

            if ($stmtCheck->num_rows > 0) {
                echo "<script>alert('Product already in your cart.');</script>";
            } else {
                // Insert into cart_items table
                $insertQuery = "INSERT INTO cart_items (p_id, customer_id, p_name, price, image) VALUES (?, ?, ?, ?, ?)";
                $stmtInsert = $con->prepare($insertQuery);
                
                if ($stmtInsert) {
                    $stmtInsert->bind_param('iissd', $product_id, $customerId, $product_name, $product_price, $image);
                    
                    if ($stmtInsert->execute()) {
                        echo "<script>
                                alert('Data successfully added to cart');
                                window.location.href = 'cart.php';
                              </script>";
                        exit();
                    } else {
                        echo "<p>Error adding to cart.</p>";
                    }
                } else {
                    echo "<p>Database query failed.</p>";
                }
            }
        } else {
            echo "<p>Database query failed.</p>";
        }
    } else {
        echo "<script>alert('Please log in to add products to your cart.');</script>";
    }
}

// Fetch products from database based on the query
$query = "SELECT * FROM products";

// Check if the price range is selected
if (isset($_GET['price_range']) && !empty($_GET['price_range'])) {
    $priceRanges = $_GET['price_range'];
    $conditions = [];

    foreach ($priceRanges as $range) {
        list($minPrice, $maxPrice) = explode('-', $range);
        $conditions[] = "(productPrice BETWEEN $minPrice AND $maxPrice)";
    }

    // Join conditions with OR operator
    if (!empty($conditions)) {
        $query .= " WHERE " . implode(' OR ', $conditions);
    }
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Duaa Mart</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">
    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid">
        <div class="row align-items-center bg-light py-3 px-xl-5 d-none d-lg-flex">
            <div class="col-lg-4">
                <a href="" class="text-decoration-none">
                    <span class="h1 text-uppercase text-primary bg-dark px-2">Duaa</span>
                    <span class="h1 text-uppercase text-dark bg-primary px-2 ml-n1">Mart</span>
                </a>
            </div>
            <div class="col-lg-4 col-6 text-left">
                <form action="">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search for products" name="search_query">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit" name="submit_search">
                                <i class="fa fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-lg-4 col-6 text-right">
                <p class="m-0">Customer Service</p>
                <h5 class="m-0">+92 318 3288 238</h5>
            </div>
        </div>
    </div>
    <!-- Topbar End -->

    <!-- Navbar Start -->
    <div class="container-fluid bg-dark mb-30">
        <div class="row px-xl-5">
            <div class="col-lg-3 d-none d-lg-block">
                <a class="btn d-flex align-items-center justify-content-between bg-primary w-100" data-toggle="collapse" href="#navbar-vertical" style="height: 65px; padding: 0 30px;">
                    <h6 class="text-dark m-0"><i class="fa fa-bars mr-2"></i>Categories</h6>
                    <i class="fa fa-angle-down text-dark"></i>
                </a>
                <nav class="collapse position-absolute navbar navbar-vertical navbar-light align-items-start p-0 bg-light" id="navbar-vertical" style="width: calc(100% - 30px); z-index: 999;">
                    <div class="navbar-nav w-100">
                        <a href="Mobile.php" class="nav-item nav-link">Mobile</a>
                        <a href="Computer.php" class="nav-item nav-link">Computer</a>
                        <a href="Jewelry.php" class="nav-item nav-link">Jewelry</a>
                        <a href="men.php" class="nav-item nav-link">Men</a>
                        <a href="Women.php" class="nav-item nav-link">Women</a>
                        <a href="kids.php" class="nav-item nav-link">Kids</a>
                    </div>
                </nav>
            </div>
            <div class="col-lg-9">
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-0">
                    <a href="" class="text-decoration-none d-block d-lg-none">
                        <span class="h1 text-uppercase text-dark bg-light px-2">Duaa</span>
                        <span class="h1 text-uppercase text-light bg-primary px-2 ml-n1">Mart</span>
                    </a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto py-0">
                            <a href="index.php" class="nav-item nav-link">Home</a>
                            <a href="about.php" class="nav-item nav-link">About us</a>
                            <a href="Product.php" class="nav-item nav-link">Products</a>
                            <a href="store.php" class="nav-item nav-link">Store</a>
                            <a href="contact.php" class="nav-item nav-link">Contact</a>
                        </div>
                        <div class="navbar-nav ml-auto py-0 d-none d-lg-block">
                            <a href="cart.php" class="btn px-0">
                                <i class="fas fa-heart text-primary"></i>
                                <span class="badge text-secondary border border-secondary rounded-circle" style="padding-bottom: 2px;">0</span>
                            </a>
                            <a href="" class="btn px-0 ml-3">
                                <i class="fas fa-shopping-cart text-primary"></i>
                                <span class="badge text-secondary border border-secondary rounded-circle" style="padding-bottom: 2px;">0</span>
                            </a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
    <!-- Navbar End -->

    <!-- Breadcrumb Start -->
    <div class="container-fluid">
        <div class="row px-xl-5">
            <div class="col-12">
                <nav class="breadcrumb bg-light mb-30">
                    <a class="breadcrumb-item text-dark" href="index.php">Home</a>
                    <a class="breadcrumb-item text-dark" href="Product.php">Products</a>
                    <span class="breadcrumb-item active">Product list</span>
                </nav>
            </div>
        </div>
    </div>
    <!-- Breadcrumb End -->
    <?php 
    // Handle search query
if (isset($_GET['submit_search'])) {
    // Get the search query
    $search_query = $_GET['search_query'];
    // Prepare SQL query to search by product name
    $sql = "SELECT * FROM products WHERE productName LIKE '%$search_query%'";
    // Execute SQL query
    $result = mysqli_query($con, $sql);
    // Check if results found
    if ($result && $result->num_rows > 0) {
        // Products found, display them
        echo '<div class="container">';
        echo '<div class="row pb-3">';
        while ($row = $result->fetch_assoc()) {
            $productId = $row['id'];
            $productName = $row['productName'];
            $productPrice = $row['productPrice'];
            $productDescription = $row['productDescription'];
            $productImg = $row['p_img'];
            echo '<div class="col-lg-4 col-md-6 col-sm-6 pb-1">';
            echo '<div class="product-item bg-light mb-4">';
            echo '<div class="product-img position-relative overflow-hidden">';
            echo '<a href="detail.php?id=' . $productId . '">';
            echo '<img src="../multishop/dashmin/' . $productImg . '" alt="' . $productName . '" style="width: 280px; height:240px;">';
            echo '</a>';
            echo '</div>';
            echo '<div class="position-relative">';
            echo '<h3 class="text-center"><a href="detail.php?id=' . $productId . '" class="text-dark">' . $productName . '</a></h3>';
            echo '<div class="d-flex align-items-center justify-content-center">';
            echo '<span class="text-dark font-weight-bold">$' . $productPrice . '</span>';
            echo '</div>';
            echo '<div class="d-flex flex-row align-items-center">';
            echo '<form method="POST" action="" style="display:inline;">';
            echo '<input type="hidden" name="product_id" value="' . $productId . '">';
            echo '<button type="submit" name="add_to_wishlist" class="btn btn-outline-danger px-3 btn-square">';
            echo '<i class="fa fa-heart mr-1"></i> ';
            echo '</button>';
            echo '</form>';
            echo '<div class="flex-grow-1"></div>'; // Flexible spacer
            echo '<form method="POST" action="">';
            echo '<input type="hidden" name="product_id" value="' . $productId . '">';
            echo '<input type="hidden" name="product_name" value="' . $productName . '">';
            echo '<input type="hidden" name="product_price" value="' . $productPrice . '">';
            echo '<button type="submit" name="add_to_cart" class="btn btn-primary px-3"><i class="fa fa-shopping-cart mr-1"></i></button>';
            echo '</form>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
        echo '</div>';
        echo '</div>';
    } else {
        // No products found
        echo "<div class='container'><div class='row'><div class='col-12'><p>No products found.</p></div></div></div>";
    }
} else {
    // Execute main product query
    $result = mysqli_query($con, $query);
} ?>

    <!-- Shop Start -->
    <div class="container-fluid">
        <div class="row px-xl-5">
            <!-- Shop Sidebar Start -->
            <!-- You can add sidebar content here if needed -->
            <!-- Shop Sidebar End -->

            <!-- Shop Product Start -->
            <div class="col-lg-9 col-md-8">
                <!-- Display fetched products -->
                <?php
                if ($result && $result->num_rows > 0) {
                    echo '<div class="container">';
                    echo '<div class="row pb-3">';
                    while ($row = $result->fetch_assoc()) {
                        $productId = $row['id'];
                        $productName = $row['productName'];
                        $productPrice = $row['productPrice'];
                        $productDescription = $row['productDescription'];
                        $productImg = $row['p_img'];
                        echo '<div class="col-lg-4 col-md-6 col-sm-6 pb-1">';
                        echo '<div class="product-item bg-light mb-4">';
                        echo '<div class="product-img position-relative overflow-hidden">';
                        echo '<a href="detail.php?id=' . $productId . '">';
                        echo '<img src="../multishop/dashmin/' . $productImg . '" alt="' . $productName . '" style="width: 280px; height:240px;">';
                        echo '</a>';
                        echo '</div>';
                        echo '<div class="position-relative">';
                        echo '<h3 class="text-center"><a href="detail.php?id=' . $productId . '" class="text-dark">' . $productName . '</a></h3>';
                        echo '<div class="d-flex align-items-center justify-content-center">';
                        echo '<span class="text-dark font-weight-bold">$' . $productPrice . '</span>';
                        echo '</div>';
                        echo '<div class="d-flex flex-row align-items-center">';
                        echo '<form method="POST" action="" style="display:inline;">';
                        echo '<input type="hidden" name="product_id" value="' . $productId . '">';
                        echo '<button type="submit" name="add_to_wishlist" class="btn btn-outline-danger px-3 btn-square">';
                        echo '<i class="fa fa-heart mr-1"></i> Add to Wishlist';
                        echo '</button>';
                        echo '</form>';
                        echo '<div class="flex-grow-1"></div>'; // Flexible spacer
                        echo '<form method="POST" action="">';
                        echo '<input type="hidden" name="product_id" value="' . $productId . '">';
                        echo '<input type="hidden" name="product_name" value="' . $productName . '">';
                        echo '<input type="hidden" name="product_price" value="' . $productPrice . '">';
                        echo '<button type="submit" name="add_to_cart" class="btn btn-primary px-3"><i class="fa fa-shopping-cart mr-1"></i> Add to Cart</button>';
                        echo '</form>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                        echo '</div>';
                    }
                    echo '</div>';
                    echo '</div>';
                } else {
                    echo "<div class='container'><div class='row'><div class='col-12'><p>No products found.</p></div></div></div>";
                }
                ?>
            </div>
            <!-- Shop Product End -->
        </div>
    </div>
    <!-- Shop End -->

    <!-- Footer Start -->
    <?php include('footer/footer.php'); ?>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
<?php
// Close database connection
mysqli_close($con);
?>

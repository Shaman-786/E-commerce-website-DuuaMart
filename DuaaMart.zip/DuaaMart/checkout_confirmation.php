<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout Confirmation</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        .card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Order Confirmation</h2>
        <div class="row">
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Customer Details</h5>
                        <p class="card-text"><strong>Name:</strong> <?php echo $_POST['first_name']; ?></p>
                        <p class="card-text"><strong>Email:</strong> <?php echo $_POST['email']; ?></p>
                        <p class="card-text"><strong>Mobile:</strong> <?php echo $_POST['mobile']; ?></p>
                        <p class="card-text"><strong>State:</strong> <?php echo $_POST['state']; ?></p>
                        <p class="card-text"><strong>City:</strong> <?php echo $_POST['city']; ?></p>
                        <p class="card-text"><strong>Address:</strong> <?php echo $_POST['address']; ?></p>
                        <p class="card-text"><strong>Payment Method:</strong> <?php echo $_POST['payment']; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card mb-4">
                    <div class="card-body">
                        <h5 class="card-title">Order Details</h5>
                        <p class="card-text"><strong>Subtotal: $</strong> <?php echo $_POST['subtotal']; ?></p>
                        <p class="card-text"><strong>Total: $</strong> <?php echo $_POST['total']; ?></p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Products</h5>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Product ID</th>
                                    <th>Product Name</th>
                                    <th>Product Price</th>
                                    <th>Product Quantity</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($_POST['product_ids'] as $index => $product_id) { ?>
                                    <tr>
                                        <td><?php echo $product_id; ?></td>
                                        <td><?php echo $_POST['product_names'][$index]; ?></td>
                                        <td><?php echo $_POST['product_prices'][$index]; ?></td>
                                        <td><?php echo $_POST['product_quantities'][$index]; ?></td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="text-center mt-4">
            <button class="btn btn-primary" onclick="confirmOrder()">Confirm Order</button>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script>
        function confirmOrder() {
            // Perform any additional confirmation steps if needed
            alert('Order confirmed successfully!');
            window.location.href = 'thank_you.php'; // Redirect to thank you page
        }
    </script>
</body>
</html>

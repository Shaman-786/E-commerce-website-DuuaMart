<?php
session_start();
include('db.php'); // Assuming this file connects to your database

if (!isset($_SESSION['email'])) {
    header('Location: login.php');
    exit;
}

$session = $_SESSION['email'];
$query = "SELECT * FROM customers WHERE email=?";
$stmt = $con->prepare($query);
$stmt->bind_param("s", $session);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

$first_name = htmlspecialchars($row['first_name']);
$last_name = htmlspecialchars($row['last_name']);
$email = htmlspecialchars($row['email']);
$phone = htmlspecialchars($row['phone']);
$address = htmlspecialchars($row['address']);
$image_path = htmlspecialchars($row['image_path']);

// Fetch wishlist items for the logged-in customer
$customerId = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
$sql = "SELECT * FROM wishlist WHERE customer_id = ?";
$stmt = $con->prepare($sql);
$stmt->bind_param("i", $customerId);
$stmt->execute();
$resultWishlist = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Duaa Mart</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
<style type="text/css">
        .main-body {
            padding: 15px;
        }
        .card {
            box-shadow: 0 1px 3px 0 rgba(0,0,0,.1), 0 1px 2px 0 rgba(0,0,0,.06);
            position: relative;
            display: flex;
            flex-direction: column;
            min-width: 0;
            word-wrap: break-word;
            background-color: #fff;
            background-clip: border-box;
            border: 0 solid rgba(0,0,0,.125);
            border-radius: .25rem;
           
        }
        .card-body {
            flex: 1 1 auto;
            min-height: 1px;
            padding: 1rem;
        }
        .gutters-sm {
            margin-right: -8px;
            margin-left: -8px;
        }
        .gutters-sm>.col, .gutters-sm>[class*=col-] {
            padding-right: 8px;
            padding-left: 8px;
        }
        .mb-3, .my-3 {
            margin-bottom: 1rem!important;
        }
        .bg-gray-300 {
            background-color: #e2e8f0;
        }
        .h-100 {
            height: 100%!important;
        }
        .shadow-none {
            box-shadow: none!important;
        }
    </style>
</head>

<body>
    <?php include('header/header.php'); ?>

    <!-- Navbar End -->

    <div class="container">
        <div class="main-body">
            <!-- Breadcrumb -->
            <nav aria-label="breadcrumb" class="main-breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                    <li class="breadcrumb-item"><a href="javascript:void(0)">User</a></li>
                    <li class="breadcrumb-item active" aria-current="page">User Profile</li>
                </ol>
            </nav>
            <!-- /Breadcrumb -->

            <div class="row gutters-sm">
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <div class="d-flex flex-column align-items-center text-center">
                                <img src="<?php echo $image_path; ?>" alt="<?php echo $first_name; ?>" width="130px" height="100px" style="border-radius: 50%;">
                                <div class="mt-3">
                                    <h2><?php echo $first_name; ?> <?php echo $last_name; ?></h2>
                                    <p class="text-muted font-size-sm"><?php echo $address; ?></p>
                                    <button class="btn btn-primary">Follow</button>
                                    <button class="btn btn-outline-primary">Message</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card mt-3">
                        <ul class="list-group list-group-flush">
                            <!-- Sidebar links -->
                            <!-- Manage Profile -->
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <div class="col-lg-4 col-6 text-right">
                                    <p class="m-0"></p>
                                    <h5 class="m-0 dropdown">
                                        <a class="dropdown-toggle" role="" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Manage Profile
                                        </a>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                            <a class='dropdown-item text-black' href='Password.php?user_id=<?php echo $row['user_id']; ?>' style="color: black;">Forgot Password</a>
                                            <a class='dropdown-item text-black' href='ch_pass.php?user_id=<?php echo $row['user_id']; ?>' style="color: black;">Change Password</a>
                                            <a class='dropdown-item text-black' href='update.php?user_id=<?php echo $row['user_id']; ?>' style="color: black;">Update Profile</a>
                                        </div>
                                    </h5>
                                </div>
                                <!-- <h6 class="mb-0">Website</h6> -->
                            </li>
                            <!-- My Wishlist -->
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <div class="col-lg-4 col-6 text-justify">
                                    <p class="m-0"></p>
                                    <h5 class="m-0 dropdown" style="width:170px;">
                                        <a class='' href='mywish.php?user_id=<?php echo $row['user_id']; ?>'>My Wishlist</a>
                                    </h5>
                                </div>
                            </li>
                            <!-- My Carts -->
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <div class="col-lg-4 col-6 text-justify">
                                    <p class="m-0"></p>
                                    <h5 class="m-0 dropdown" style="width:170px;">
                                    </h5>
                                </div>
                            </li>
                            <!-- My Orders -->
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <div class="col-lg-4 col-6 text-justify">
                                    <p class="m-0"></p>
                                    <h5 class="m-0 dropdown" style="width:170px;">
                                        <a class='' href='myorders.php?user_id=<?php echo $row['user_id']; ?>'>My Orders</a>
                                    </h5>
                                </div>
                            </li>
                            <!-- Products -->
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <div class="col-lg-4 col-6 text-justify">
                                    <p class="m-0"></p>
                                    <h5 class="m-0 dropdown" style="width:170px;">
                                        <a class='' href='Pur_product.php?user_id=<?php echo $row['user_id']; ?>'>Products</a>
                                    </h5>
                                </div>
                            </li>

                            <!-- Delete Account -->
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <div class="col-lg-4 col-6 text-justify">
                                    <p class="m-0"></p>
                                    <h5 class="m-0 dropdown" style="width:170px;">
                                        <a class='' href='deleteacc.php?user_id=<?php echo $row['user_id']; ?>'>Delete Account</a>
                                    </h5>
                                </div>
                            </li>
                            <!-- Logout -->
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <div class="col-lg-4 col-6 text-justify">
                                    <p class="m-0"></p>
                                    <h5 class="m-0 dropdown" style="width:170px;">
                                        <a class='' href='logout.php?user_id=<?php echo $row['user_id']; ?>'>Logout</a>
                                    </h5>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>

                <!-- Wishlist Section -->
                <div class="col-md-8">
                    <h5 class="text-center mb-4">My Wishlist</h5>
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Product ID</th>
                                            <th scope="col">Product Name</th>
                                            <th scope="col">Unit Price</th>
                                            <th scope="col">Product Image</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        // Fetch and display wishlist items
                                        if ($resultWishlist->num_rows > 0) {
                                            while($rowWishlist = $resultWishlist->fetch_assoc()) {
                                                echo "<tr>";
                                                echo "<td>" . $rowWishlist["product_id"] . "</td>";
                                                echo "<td>" . $rowWishlist["product_name"] . "</td>";
                                                echo "<td>" . $rowWishlist["unit_price"] . "</td>";
                                                echo "<td><img src='" . $rowWishlist["product_image"] . "' alt='" . $rowWishlist["product_name"] . "' style='max-width: 100px; max-height: 100px;'></td>";
                                                echo "<td>" . $rowWishlist["stock_status"] . "</td>";
                                                echo "</tr>";
                                            }
                                        } else {
                                            echo "<tr><td colspan='5'>No items in wishlist</td></tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Start -->
    <?php include('footer/footer.php'); ?>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>
